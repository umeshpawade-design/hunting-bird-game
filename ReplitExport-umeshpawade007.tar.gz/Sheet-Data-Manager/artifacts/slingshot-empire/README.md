# Slingshot Empire: Invasion Overdrive Pro

A professional, cross-platform Pygame slingshot action game rebuilt for desktop and Android.

## What changed

The original single-file prototype was refactored into a clean, modular architecture. Key improvements:

- **Modular code**: Game split into `core`, `entities`, `systems`, `ui`, `utils`.
- **Bug fixes**: Bird respawning, combo system, projectile drawing, screen-shake, collision accuracy.
- **Performance**: Cached surfaces/fonts, capped dt, object pooling, reduced per-frame allocations.
- **Mobile ready**: Touch controls, dynamic resolution, safe areas, on-screen buttons, Android build config (`buildozer.spec`).
- **Save system**: JSON profile save/load with validation and backups.
- **Audio**: Pure-Python synth SFX + background music, no external asset dependencies.
- **Sprites**: Runtime sprite atlas generates stylized placeholder art; drop custom PNGs in `assets/images/` to override them.
- **3D effects**: Parallax starfield, drop shadows, perspective scaling, and camera tilt for a premium look.
- **Haptic feedback**: Vibration on Android for shooting, hits, and game over (via `systems/vibration.py`).
- **Ads stub**: AdMob facade ready for a python-for-android recipe (`systems/ads.py`).

## Run on desktop

```bash
cd artifacts/slingshot-empire
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
python src/main.py
```

## Controls

- **Mouse / touch**: Drag from the slingshot to aim, release to shoot.
- **Weapon tabs**: Click the right-side weapon cards to switch ammo (Plasma / Ballista are only available during boss fights).
- **Shop / Pause**: Tap the HUD buttons.
- **Esc**: Quit (desktop only).

## Build for Android (Google Play Store)

1. Install Buildozer and dependencies:

```bash
pip install buildozer cython
sudo apt update && sudo apt install -y git zip unzip openjdk-17-jdk python3-pip autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libffi-dev libssl-dev libltdl-dev
```

2. Build the APK:

```bash
cd artifacts/slingshot-empire
buildozer -v android debug
```

3. For release:

```bash
buildozer -v android release
```

Make sure to update `buildozer.spec` with your package name, version, and signing keystore before Play Store upload.

## Project structure

```text
artifacts/slingshot-empire/
├── src/
│   ├── main.py              # Entry point
│   ├── config.py            # Constants, colors, difficulty settings
│   ├── core/
│   │   ├── engine.py        # Main game loop, state manager
│   │   └── states.py        # Menu, Ready, Shop, Pause, GameOver, Victory
│   ├── entities/
│   │   ├── bird.py          # Enemy birds (normal, alpha, golden)
│   │   ├── boss.py          # Boss waves and projectiles
│   │   ├── arrow.py         # Player arrows / slingshot physics
│   │   └── particle.py      # Particle effects and trails
│   ├── systems/
│   │   ├── physics.py       # Collision, movement, object management
│   │   ├── audio.py         # Procedural sound effects + music
│   │   ├── save_manager.py  # JSON profile persistence
│   │   ├── sprite_atlas.py  # Runtime sprite generation + external asset loading
│   │   ├── vibration.py     # Cross-platform haptic feedback wrapper
│   │   └── ads.py           # AdMob integration facade
│   ├── ui/
│   │   ├── widgets.py       # Buttons, labels, panels
│   │   └── hud.py           # Heads-up display
│   └── utils/
│       └── helpers.py       # Utility functions (fonts, clamp, etc.)
├── assets/                  # Sound/image placeholders
├── buildozer.spec           # Android packaging config
└── requirements.txt         # Python dependencies
```
