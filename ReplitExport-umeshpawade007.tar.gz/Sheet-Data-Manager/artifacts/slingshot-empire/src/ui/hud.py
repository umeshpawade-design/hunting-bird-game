"""Heads-up display, weapon tabs, progress bars, and banners."""

from __future__ import annotations

import math
from typing import List, Tuple
import pygame

from config import (
    SETTINGS, CHARCOAL, WHITE, GOLD, DEEP_RED, BRIGHT_GREEN, PURPLE, ORANGE,
    COIN_VISIBILITY_COLOR, WEAPONS, MAX_COMBO_TIME,
)
from ui.widgets import Button, Label
from utils.helpers import get_font


class HUD:
    """All in-game HUD rendering."""

    def __init__(self) -> None:
        self.shop_btn = Button(0, 0, 140, 45, "SHOP ARMORY", CHARCOAL, BRIGHT_GREEN, WHITE, 14)
        self.pause_btn = Button(0, 0, 190, 45, "PAUSE", CHARCOAL, DEEP_RED, WHITE, 16)
        self.weapon_tabs: List[Button] = []
        self._rebuild_layout()

    def _rebuild_layout(self) -> None:
        self.shop_btn.set_position(SETTINGS.hud_margin, SETTINGS.height - 110)
        self.pause_btn.set_position(SETTINGS.width - 220, SETTINGS.height - 285)

        self.weapon_tabs.clear()
        for i, w_id in enumerate(["STANDARD", "PLASMA", "BALLISTA"]):
            rect = pygame.Rect(SETTINGS.width - 220, SETTINGS.height - 220 + i * 55, 190, 45)
            btn = Button(rect.x, rect.y, rect.width, rect.height, "", CHARCOAL, BRIGHT_GREEN, WHITE, 14)
            self.weapon_tabs.append(btn)

    def update_layout(self) -> None:
        self._rebuild_layout()

    def update(self, mx: int, my: int, touch_down: bool, touch_up: bool, state) -> list:
        """Handle HUD interactions. Returns a list of actions triggered."""
        actions = []
        if self.shop_btn.update(mx, my, touch_down, touch_up):
            actions.append("shop")
        if self.pause_btn.update(mx, my, touch_down, touch_up):
            actions.append("pause")

        for i, tab in enumerate(self.weapon_tabs):
            w_id = ["STANDARD", "PLASMA", "BALLISTA"][i]
            if tab.update(mx, my, touch_down, touch_up):
                actions.append(("weapon", w_id))
        return actions

    def draw(self, surface: pygame.Surface, state) -> None:
        # Top-left score / level
        text_color = CHARCOAL if state.level <= 30 else WHITE
        labels = [
            (f"SCORE: {state.score}", 30, 30, text_color),
            (f"LEVEL: {state.level} ({state.difficulty})", 30, 75, BRIGHT_GREEN),
        ]
        for text, x, y, color in labels:
            draw_text(surface, text, x, y, 36, color)

        # Top-right coins / arrows
        draw_text(surface, f"ARROWS: {state.lives}", SETTINGS.width - 240, 95, 36, DEEP_RED)
        draw_text(surface, f"COINS: {state.coins}", SETTINGS.width - 240, 30, 36, COIN_VISIBILITY_COLOR)

        # Buttons
        self.shop_btn.draw(surface)
        self.pause_btn.draw(surface)

        # HP bar
        hp_bar_x = 30
        hp_bar_y = SETTINGS.height - 60
        hp_bar_w = 200
        hp_bar_h = 20
        pygame.draw.rect(surface, CHARCOAL, (hp_bar_x, hp_bar_y, hp_bar_w, hp_bar_h), border_radius=4)
        hp_ratio = max(0, min(1, state.current_hp / state.max_hp))
        hp_color = BRIGHT_GREEN if state.current_hp > state.max_hp * 0.3 else DEEP_RED
        pygame.draw.rect(surface, hp_color, (hp_bar_x, hp_bar_y, int(hp_bar_w * hp_ratio), hp_bar_h), border_radius=4)
        draw_text(surface, f"HP: {state.current_hp}/{state.max_hp}", hp_bar_x, hp_bar_y - 35, 26, text_color)

        # Weapon tabs
        for i, tab in enumerate(self.weapon_tabs):
            w_id = ["STANDARD", "PLASMA", "BALLISTA"][i]
            w_data = WEAPONS[w_id]
            is_locked = (not state.boss_active) and w_id != "STANDARD"
            qty_label = "INF" if w_data["qty"] == -1 else str(w_data["qty"])
            display = f"{w_data['name']} [{qty_label}]"

            if is_locked:
                tab.base_color = (25, 25, 30)
                tab.border_color = (50, 50, 55)
                tab.text_color = (100, 100, 105)
                display += " [LOCKED]"
            else:
                if state.selected_weapon == w_id:
                    tab.base_color = BRIGHT_GREEN
                    tab.border_color = WHITE
                    tab.text_color = WHITE
                else:
                    tab.base_color = CHARCOAL
                    tab.border_color = WHITE
                    tab.text_color = WHITE
                    if state.lives <= 0 and w_data["qty"] > 0:
                        if int(pygame.time.get_ticks() / 200) % 2 == 0:
                            tab.base_color = DEEP_RED

            tab.text = display
            tab.draw(surface)

        # Invasion progress bar
        if not state.boss_active:
            bar_x = SETTINGS.width // 2 - 220
            bar_y = int(SETTINGS.slingshot_y + 160)
            pygame.draw.rect(surface, CHARCOAL, (bar_x, bar_y, 440, 42), border_radius=8)
            progress = f"INVASION PROGRESS: {state.level_score_tracker}/{state.points_for_level_up}"
            draw_text(surface, progress, SETTINGS.width // 2, bar_y + 21, 24, WHITE, center=True)
        else:
            # Boss HP bar
            bar_x = SETTINGS.width // 2 - 220
            pygame.draw.rect(surface, DEEP_RED, (bar_x, 24, 440, 24), border_radius=6)
            hp_ratio = state.boss_current_hp / max(1, state.boss_max_hp)
            pygame.draw.rect(surface, BRIGHT_GREEN, (bar_x, 24, int(440 * hp_ratio), 24), border_radius=6)
            pygame.draw.rect(surface, CHARCOAL, (bar_x, 24, 440, 24), width=2, border_radius=6)
            boss_text = f"WAVE ({state.boss_current_wave}/{state.boss_total_waves}) BOSS HP: {state.boss_current_hp}/{state.boss_max_hp}"
            draw_text(surface, boss_text, SETTINGS.width // 2, 54, 24, WHITE, center=True)

        # Triple shot timer
        if state.triple_shot_timer > 0:
            draw_text(surface, f"TRIPLE SHOT: {round(state.triple_shot_timer, 1)}s", 30, 200, 24, PURPLE)

        # Combo
        if state.combo_multiplier > 1:
            draw_text(surface, f"COMBO x{state.combo_multiplier}!", 30, 120, 26, GOLD)
            pygame.draw.rect(surface, GOLD, (30, 160, int(120 * (state.combo_meter / MAX_COMBO_TIME)), 6))

        # Level up banner
        if state.level_up_banner_time > 0:
            alpha = int(abs(math.sin(state.global_time * 8)) * 100) + 100
            banner = pygame.Surface((SETTINGS.width, 140), pygame.SRCALPHA)
            banner.fill((0, 0, 0, alpha))
            surface.blit(banner, (0, SETTINGS.height // 3 - 20))
            draw_text(surface, f"LEVEL {state.level} ASSAULT!", SETTINGS.width // 2, SETTINGS.height // 3 + 2, 64, GOLD, center=True)


def draw_text(surface, text, x, y, size, color, center=False):
    font = get_font(size, bold=True)
    surf = font.render(text, True, color)
    rect = surf.get_rect()
    if center:
        rect.center = (x, y)
    else:
        rect.topleft = (x, y)
    surface.blit(surf, rect)
