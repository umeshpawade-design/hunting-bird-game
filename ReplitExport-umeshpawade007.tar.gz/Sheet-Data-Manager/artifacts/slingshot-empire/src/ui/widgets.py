"""Reusable UI widgets: buttons, panels, labels, and input fields."""

from __future__ import annotations

from typing import Tuple, Callable, Optional
import pygame

from config import CHARCOAL, WHITE, GOLD, GRAY, BLACK, SETTINGS
from utils.helpers import get_font, clamp, color_lerp, draw_drop_shadow


_BUTTON_RADIUS = 18


def _make_gradient(size: Tuple[int, int], top: Tuple[int, int, int],
                   bottom: Tuple[int, int, int]) -> pygame.Surface:
    """Create a small vertical gradient surface for a button."""
    w, h = size
    surf = pygame.Surface((w, h), pygame.SRCALPHA)
    for y in range(h):
        t = y / h
        c = color_lerp(top, bottom, t)
        pygame.draw.line(surf, c, (0, y), (w, y))
    return surf


class Button:
    """A premium clickable button with gradient, shadow, and hover/press states."""

    def __init__(self, x: float, y: float, width: float, height: float,
                 text: str, base_color: Tuple[int, int, int], hover_color: Tuple[int, int, int],
                 text_color: Tuple[int, int, int] = WHITE, font_size: int = 24,
                 border_color: Tuple[int, int, int] = CHARCOAL, on_click: Optional[Callable] = None,
                 disabled: bool = False, icon: Optional[str] = None) -> None:
        self.rect = pygame.Rect(int(x), int(y), int(width), int(height))
        self.text = text
        self.base_color = base_color
        self.hover_color = hover_color
        self.text_color = text_color
        self.font_size = font_size
        self.border_color = border_color
        self.on_click = on_click
        self.disabled = disabled
        self.icon = icon
        self.hovered = False
        self.pressed = False
        self._scale = 1.0

    def update(self, mx: int, my: int, touch_down: bool, touch_up: bool) -> bool:
        """Return True if the button was clicked this frame."""
        if self.disabled:
            self.hovered = False
            self.pressed = False
            self._scale = 1.0
            return False

        self.hovered = self.rect.collidepoint(mx, my)
        self.pressed = self.hovered and touch_down

        target = 1.05 if self.hovered else 1.0
        if self.pressed:
            target = 0.98
        self._scale = clamp(self._scale + (target - self._scale) * 0.25, 0.95, 1.08)

        if touch_up and self.hovered:
            if self.on_click:
                self.on_click()
            return True
        return False

    def draw(self, surface: pygame.Surface) -> None:
        t = 1.0 if self.hovered else 0.0
        base = self.base_color
        hover = self.hover_color
        top = color_lerp(base, hover, t)
        bottom = color_lerp(tuple(max(0, c - 35) for c in base),
                            tuple(max(0, c - 15) for c in hover), t)

        # Soft drop shadow below the button
        if not self.disabled:
            draw_drop_shadow(surface, self.rect.centerx, self.rect.centery + self.rect.height // 2,
                             self.rect.width, self.rect.height,
                             alpha=50, blur=4)

        # Scaled draw rect
        scaled = self.rect.copy()
        if self._scale != 1.0:
            scaled.width = int(self.rect.width * self._scale)
            scaled.height = int(self.rect.height * self._scale)
            scaled.center = self.rect.center

        # Gradient body
        grad = _make_gradient((scaled.width, scaled.height), top, bottom)
        surface.blit(grad, scaled.topleft)

        # Clean outer border
        border = color_lerp(self.border_color, GOLD, t * 0.5)
        pygame.draw.rect(surface, border, scaled, width=2, border_radius=_BUTTON_RADIUS)

        # Subtle top highlight
        hl_color = tuple(min(255, c + 50) for c in top)
        pygame.draw.line(surface, hl_color,
                         (scaled.left + _BUTTON_RADIUS, scaled.top + 2),
                         (scaled.right - _BUTTON_RADIUS, scaled.top + 2), 1)

        # Text with soft shadow for readability
        font = get_font(self.font_size, bold=True)
        text_surf = font.render(self.text, True, self.text_color)
        shadow = font.render(self.text, True, (0, 0, 0))
        text_rect = text_surf.get_rect(center=scaled.center)
        shadow_rect = text_rect.copy()
        shadow_rect.x += 1
        shadow_rect.y += 1
        surface.blit(shadow, shadow_rect, special_flags=pygame.BLEND_ALPHA_SDL2)
        surface.blit(text_surf, text_rect)

    def set_position(self, x: float, y: float) -> None:
        self.rect.x = int(x)
        self.rect.y = int(y)


class Label:
    """Simple text label."""

    def __init__(self, x: float, y: float, text: str = "", size: int = 24,
                 color: Tuple[int, int, int] = WHITE, center: bool = False) -> None:
        self.x = int(x)
        self.y = int(y)
        self.text = text
        self.size = size
        self.color = color
        self.center = center
        self._surface = None
        self._rect = None
        self._last_text = None
        self._update_surface()

    def _update_surface(self) -> None:
        if self.text == self._last_text:
            return
        self._last_text = self.text
        font = get_font(self.size, bold=True)
        self._surface = font.render(self.text, True, self.color)
        self._rect = self._surface.get_rect()
        if self.center:
            self._rect.center = (self.x, self.y)
        else:
            self._rect.topleft = (self.x, self.y)

    def set_text(self, text: str) -> None:
        self.text = text
        self._update_surface()

    def set_position(self, x: float, y: float) -> None:
        self.x = int(x)
        self.y = int(y)
        self._update_surface()

    def draw(self, surface: pygame.Surface) -> None:
        self._update_surface()
        if self._surface is not None:
            surface.blit(self._surface, self._rect)


class TextInput:
    """A single-line text input field."""

    def __init__(self, x: float, y: float, width: float, height: float,
                 label: str = "Name", max_length: int = 14) -> None:
        self.rect = pygame.Rect(int(x), int(y), int(width), int(height))
        self.label = label
        self.text = "Player 1"
        self.active = False
        self.max_length = max_length
        self.cursor_visible = False
        self.cursor_timer = 0.0

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.TEXTINPUT:
            if self.active and len(self.text) < self.max_length:
                self.text += event.text
        elif event.type == pygame.KEYDOWN:
            if self.active:
                if event.key == pygame.K_BACKSPACE:
                    self.text = self.text[:-1]
                elif event.key == pygame.K_RETURN:
                    self.active = False

    def update(self, dt: float, mx: int, my: int, touch_down: bool) -> None:
        if touch_down:
            self.active = self.rect.collidepoint(mx, my)
            if self.active:
                self.text = ""
        self.cursor_timer += dt
        if self.cursor_timer >= 0.5:
            self.cursor_timer = 0.0
            self.cursor_visible = not self.cursor_visible

    def draw(self, surface: pygame.Surface) -> None:
        bg_color = WHITE if self.active else GRAY
        border_color = GOLD if self.active else CHARCOAL
        pygame.draw.rect(surface, bg_color, self.rect, border_radius=8)
        pygame.draw.rect(surface, border_color, self.rect, width=2, border_radius=8)

        font = get_font(28, bold=True)
        display = self.text
        if self.active and self.cursor_visible:
            display += "_"
        text_surf = font.render(f"{self.label}: {display}", True, CHARCOAL)
        surface.blit(text_surf, (self.rect.x + 10, self.rect.y + 6))

    def get_value(self) -> str:
        return self.text.strip()

    def set_position(self, x: float, y: float) -> None:
        self.rect.x = int(x)
        self.rect.y = int(y)


class Panel:
    """Decorated background panel with optional border and transparency."""

    def __init__(self, x: float, y: float, width: float, height: float,
                 color: Tuple[int, int, int] = CHARCOAL, border_color: Tuple[int, int, int] = GOLD,
                 alpha: int = 255) -> None:
        self.rect = pygame.Rect(int(x), int(y), int(width), int(height))
        self.color = color
        self.border_color = border_color
        self.alpha = alpha
        self._cached = None
        self._build_cache()

    def _build_cache(self) -> None:
        self._cached = pygame.Surface((self.rect.width, self.rect.height), pygame.SRCALPHA)
        self._cached.fill((*self.color, self.alpha))
        pygame.draw.rect(self._cached, self.border_color, self._cached.get_rect(), width=3, border_radius=12)

    def draw(self, surface: pygame.Surface) -> None:
        surface.blit(self._cached, self.rect.topleft)

    def set_position(self, x: float, y: float) -> None:
        self.rect.x = int(x)
        self.rect.y = int(y)
