"""Shared utility helpers: font caching, clamping, interpolation, etc."""

from __future__ import annotations

import math
import os
import random
from typing import Tuple, Optional
import pygame

from config import SETTINGS

# Font cache to avoid recreating fonts every frame
_FONT_CACHE: dict = {}

# System font paths used when SysFont is unavailable (e.g. headless/Nix environments)
_FALLBACK_FONT_PATHS = [
    "assets/fonts/default.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
]


def get_font(size: int, bold: bool = True, name: str = "Trebuchet MS") -> pygame.font.Font:
    """Return a cached Pygame font. Falls back to system/bundled fonts on error."""
    key = (name, size, bold)
    if key not in _FONT_CACHE:
        try:
            _FONT_CACHE[key] = pygame.font.SysFont(name, size, bold=bold)
        except Exception:
            for path in _FALLBACK_FONT_PATHS:
                try:
                    if os.path.exists(path):
                        _FONT_CACHE[key] = pygame.font.Font(path, size)
                        break
                except Exception:
                    continue
            else:
                _FONT_CACHE[key] = pygame.font.SysFont(None, size, bold=bold)
    return _FONT_CACHE[key]


def clear_font_cache() -> None:
    _FONT_CACHE.clear()


def clamp(value: float, min_val: float, max_val: float) -> float:
    return max(min_val, min(value, max_val))


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def color_lerp(c1: Tuple[int, int, int], c2: Tuple[int, int, int], t: float) -> Tuple[int, int, int]:
    t = clamp(t, 0.0, 1.0)
    return (
        int(lerp(c1[0], c2[0], t)),
        int(lerp(c1[1], c2[1], t)),
        int(lerp(c1[2], c2[2], t)),
    )


def fit_rect(rect: pygame.Rect, container: pygame.Rect, align: str = "center") -> pygame.Rect:
    """Center or align a rect inside a container."""
    out = rect.copy()
    if align == "center":
        out.center = container.center
    return out


def build_sky_gradient(width: int, height: int, top: Tuple[int, int, int], bottom: Tuple[int, int, int]) -> pygame.Surface:
    """Build a pre-rendered vertical gradient surface."""
    surf = pygame.Surface((width, height))
    for y in range(height):
        ratio = y / height
        r = int(top[0] * (1 - ratio) + bottom[0] * ratio)
        g = int(top[1] * (1 - ratio) + bottom[1] * ratio)
        b = int(top[2] * (1 - ratio) + bottom[2] * ratio)
        pygame.draw.line(surf, (r, g, b), (0, y), (width, y))
    return surf


def draw_text(surface: pygame.Surface, text: str, x: int, y: int, size: int = 24,
              color: Tuple[int, int, int] = (255, 255, 255), center: bool = False,
              bold: bool = True) -> pygame.Rect:
    """Simple helper to draw text. Returns the text rect."""
    font = get_font(size, bold=bold)
    text_surf = font.render(str(text), True, color)
    rect = text_surf.get_rect()
    if center:
        rect.center = (x, y)
    else:
        rect.topleft = (x, y)
    surface.blit(text_surf, rect)
    return rect


def play_sound_if_valid(sound: Optional[pygame.mixer.Sound]) -> None:
    """Play a sound safely, avoiding Channel busy errors."""
    if sound is not None:
        try:
            sound.play()
        except Exception:
            pass


def screen_shake_offset(shake_timer: float, shake_intensity: int) -> Tuple[int, int]:
    if shake_timer <= 0 or shake_intensity <= 0:
        return 0, 0
    return (
        random.randint(-shake_intensity, shake_intensity),
        random.randint(-shake_intensity, shake_intensity),
    )


# Cache for shadow surfaces so they are not recreated every frame.
_SHADOW_CACHE: dict = {}


def draw_drop_shadow(surface: pygame.Surface, x: int, y: int, w: int, h: int,
                     alpha: int = 90, blur: int = 4) -> None:
    """Draw a soft drop shadow centered under an object for a 3D floating effect."""
    if not SETTINGS.enable_shadows:
        return
    key = (w, h, alpha, blur)
    shadow = _SHADOW_CACHE.get(key)
    if shadow is None:
        shadow = pygame.Surface((w + blur * 4, h + blur * 4), pygame.SRCALPHA)
        cx, cy = (w + blur * 4) // 2, (h + blur * 4) // 2
        rx, ry = w // 2, h // 4
        for i in range(blur, 0, -1):
            a = max(5, alpha // (blur - i + 1))
            pygame.draw.ellipse(shadow, (0, 0, 0, a), (cx - rx - i, cy - ry - i, rx * 2 + i * 2, ry * 2 + i * 2))
        _SHADOW_CACHE[key] = shadow
    # Align visible shadow top with object bottom; x,y are the object center.
    blit_x = x - (w // 2 + blur * 2)
    blit_y = y + h // 4 - blur * 2
    surface.blit(shadow, (blit_x, blit_y))
