"""Advertisement integration stub + guide for Google Play release.

Pygame itself does not bundle ad SDKs. To show AdMob banners/interstitials on
Android, you need a python-for-android recipe that exposes the Android AdMob SDK
to Python. This module provides a clean facade so the rest of the game can call
ad methods without worrying about platform details.

Recommended next steps for actual AdMob integration:
1. Add a p4a recipe (e.g. `recipes/androidadmob/__init__.py`) or use an
   existing community recipe such as `kivads`/`kivmob`.
2. Set `ADMOB_APP_ID` and ad unit IDs in your environment or `config.py`.
3. Call `AdManager.initialize()` on app start, then `show_banner()` or
   `show_interstitial()` at appropriate moments.
4. Do NOT show interstitial ads during active gameplay — only at menu,
   game-over, or level-up boundaries.
"""

from __future__ import annotations

import os

ADMOB_APP_ID = os.environ.get("ADMOB_APP_ID", "")
ADMOB_BANNER_ID = os.environ.get("ADMOB_BANNER_ID", "")
ADMOB_INTERSTITIAL_ID = os.environ.get("ADMOB_INTERSTITIAL_ID", "")


try:
    # Optional Android AdMob bridge (only available with a custom p4a recipe)
    import android_admob  # type: ignore
    _AD_BACKEND = android_admob
except Exception:
    _AD_BACKEND = None


class AdManager:
    """Cross-platform ad manager facade."""

    def __init__(self, enabled: bool = True) -> None:
        self.enabled = enabled and _AD_BACKEND is not None
        self._initialized = False

    def initialize(self) -> None:
        if not self.enabled or self._initialized:
            return
        try:
            if _AD_BACKEND is not None:
                _AD_BACKEND.initialize(ADMOB_APP_ID)
            self._initialized = True
        except Exception:
            pass

    def show_banner(self) -> None:
        """Show a banner ad (safe to call repeatedly; it will just reposition)."""
        if not self.enabled:
            return
        try:
            if _AD_BACKEND is not None:
                _AD_BACKEND.show_banner(ADMOB_BANNER_ID)
        except Exception:
            pass

    def hide_banner(self) -> None:
        if not self.enabled:
            return
        try:
            if _AD_BACKEND is not None:
                _AD_BACKEND.hide_banner()
        except Exception:
            pass

    def show_interstitial(self, on_closed: callable = None) -> None:
        """Show a full-screen interstitial ad. Best used at menu/game over."""
        if not self.enabled:
            return
        try:
            if _AD_BACKEND is not None:
                _AD_BACKEND.show_interstitial(ADMOB_INTERSTITIAL_ID, on_closed)
        except Exception:
            pass

    def set_enabled(self, enabled: bool) -> None:
        self.enabled = enabled and _AD_BACKEND is not None
