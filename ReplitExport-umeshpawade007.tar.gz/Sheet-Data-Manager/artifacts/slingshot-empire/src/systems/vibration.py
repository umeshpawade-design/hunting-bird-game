"""Cross-platform vibration/haptic feedback.

On Android (python-for-android) this uses the `android` module. On desktop it
gracefully falls back to no-op or Pygame joystick rumble if available.
"""

from __future__ import annotations

from typing import Optional

# Optional Android import; only present when packaged with python-for-android.
try:
    from android import vibrate  # type: ignore
    _HAS_ANDROID = True
except Exception:
    vibrate = None
    _HAS_ANDROID = False


class VibrationManager:
    """Provides simple haptic feedback."""

    def __init__(self, enabled: bool = True) -> None:
        self.enabled = enabled and _HAS_ANDROID
        self._last_ms = 0

    def vibrate(self, milliseconds: int = 40) -> None:
        """Trigger a short vibration. Duration is capped to avoid battery drain."""
        if not self.enabled or milliseconds <= 0:
            return

        ms = min(milliseconds, 200)
        if ms == self._last_ms and ms < 50:
            # Skip redundant tiny pulses to save battery.
            return
        self._last_ms = ms

        try:
            if vibrate is not None:
                vibrate(ms)
        except Exception:
            pass

    def light(self) -> None:
        """Light feedback for small UI actions."""
        self.vibrate(20)

    def medium(self) -> None:
        """Medium feedback for shooting / collecting powerups."""
        self.vibrate(50)

    def heavy(self) -> None:
        """Heavy feedback for explosions / boss hits / game over."""
        self.vibrate(100)

    def set_enabled(self, enabled: bool) -> None:
        self.enabled = enabled and _HAS_ANDROID
