"""Runtime sprite generation and asset loading.

Generates vector-style placeholder sprites on first run so no external image
files are required. To use real art, drop PNG files into `assets/images/` with
the names below; they will be loaded automatically if present.
"""

from __future__ import annotations

import math
import os
from typing import Dict, Optional, Tuple
import pygame

from config import (
    BIRD_CYAN, BIRD_LIGHT_CYAN, BIRD_NAVY_TAIL, ALPHA_BLUE, ALPHA_GLOW, GOLD,
    WHITE, ORANGE, CHARCOAL, DEEP_RED, NEON_CYAN, GRAY, MIDNIGHT_DARK, PURPLE,
    SETTINGS,
)

ASSET_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "assets", "images")


class SpriteAtlas:
    """Owns all game sprites. Generates procedural placeholders or loads files."""

    def __init__(self) -> None:
        self._sprites: Dict[str, pygame.Surface] = {}
        self._build_all()

    def _get(self, name: str) -> Optional[pygame.Surface]:
        if name in self._sprites:
            return self._sprites[name]

        # Try loading external sprite file
        path = os.path.join(ASSET_DIR, f"{name}.png")
        if os.path.exists(path):
            try:
                surf = pygame.image.load(path)
                # convert_alpha is faster but needs a display mode; fall back to alpha-safe load.
                if pygame.display.get_surface() is not None:
                    surf = surf.convert_alpha()
                self._sprites[name] = surf
                return surf
            except Exception:
                pass
        return None

    def _set(self, name: str, surf: pygame.Surface) -> None:
        self._sprites[name] = surf

    def _build_all(self) -> None:
        # Birds
        self._build_bird("bird_normal", BIRD_CYAN, BIRD_LIGHT_CYAN, WHITE, BIRD_NAVY_TAIL, ORANGE)
        self._build_bird("bird_alpha", ALPHA_BLUE, ALPHA_GLOW, WHITE, BIRD_NAVY_TAIL, ORANGE, glow=True)
        self._build_bird("bird_golden", GOLD, WHITE, WHITE, BIRD_NAVY_TAIL, ORANGE, glow=True)

        # Bosses
        self._build_boss_phoenix()
        self._build_boss_drone()
        self._build_boss_ufo()
        self._build_boss_mothership()
        self._build_boss_omega()

        # Arrows
        self._build_arrow("arrow_standard", CHARCOAL, GOLD, 5)
        self._build_arrow("arrow_plasma", NEON_CYAN, NEON_CYAN, 7)
        self._build_arrow("arrow_ballista", DEEP_RED, GOLD, 9)

        # Slingshot and powerup
        self._build_slingshot()
        self._build_powerup()

    def _build_bird(self, name: str, body_color: Tuple[int, int, int], wing_color: Tuple[int, int, int],
                    belly_color: Tuple[int, int, int], tail_color: Tuple[int, int, int],
                    beak_color: Tuple[int, int, int], glow: bool = False) -> None:
        if self._get(name) is not None:
            return

        w, h = 96, 58
        surf = pygame.Surface((w, h), pygame.SRCALPHA)

        if glow:
            pygame.draw.ellipse(surf, (*wing_color, 90), (0, 0, w, h))

        # Tail
        pygame.draw.polygon(surf, tail_color, [(4, h // 2), (20, h // 4), (18, 3 * h // 4)])
        # Body
        pygame.draw.ellipse(surf, body_color, (16, 10, int(w * 0.55), h - 14))
        pygame.draw.ellipse(surf, belly_color, (40, 4, int(w * 0.45), h - 12))
        # Wing
        pygame.draw.ellipse(surf, wing_color, (28, 18, 42, 26))
        # Eye
        pygame.draw.circle(surf, CHARCOAL, (w - 20, h // 2 - 4), 4)
        # Beak
        pygame.draw.polygon(surf, beak_color, [(w - 12, h // 2 - 2), (w + 2, h // 2 + 4), (w - 12, h // 2 + 8)])

        self._set(name, surf)

    def _build_boss_phoenix(self) -> None:
        if self._get("boss_phoenix") is not None:
            return
        w, h = 196, 116
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.polygon(surf, CHARCOAL, [(0, h // 2), (40, h // 3), (34, 3 * h // 4)])
        pygame.draw.ellipse(surf, DEEP_RED, (20, 10, w - 40, h - 20))
        pygame.draw.ellipse(surf, PURPLE, (36, 22, w - 80, h - 50))
        pygame.draw.circle(surf, WHITE, (w - 50, h // 3), 16)
        pygame.draw.circle(surf, CHARCOAL, (w - 44, h // 3), 8)
        pygame.draw.polygon(surf, GOLD, [(w // 3, h // 2), (w // 4, 10), (w // 2, h // 3)])
        self._set("boss_phoenix", surf)

    def _build_boss_drone(self) -> None:
        if self._get("boss_drone") is not None:
            return
        w, h = 196, 116
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.rect(surf, CHARCOAL, (10, h // 3, w - 20, h // 3), border_radius=10)
        pygame.draw.circle(surf, NEON_CYAN, (w // 5, h // 2), 14)
        pygame.draw.circle(surf, NEON_CYAN, (4 * w // 5, h // 2), 14)
        pygame.draw.line(surf, WHITE, (10, h // 2), (-10, h // 4), 6)
        pygame.draw.line(surf, WHITE, (w - 10, h // 2), (w + 20, h // 4), 6)
        self._set("boss_drone", surf)

    def _build_boss_ufo(self) -> None:
        if self._get("boss_ufo") is not None:
            return
        w, h = 196, 116
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.ellipse(surf, GRAY, (0, h // 4, w, 2 * h // 3))
        pygame.draw.ellipse(surf, NEON_CYAN, (w // 4, 0, w // 2, h // 2))
        for i in range(1, 5):
            pygame.draw.circle(surf, (255, 255, 0), (i * w // 5, 3 * h // 4), 10)
        self._set("boss_ufo", surf)

    def _build_boss_mothership(self) -> None:
        if self._get("boss_mothership") is not None:
            return
        w, h = 196, 116
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.rect(surf, MIDNIGHT_DARK, (0, 0, w, h), border_radius=16)
        pygame.draw.rect(surf, ORANGE, (12, 12, w - 24, h - 24), width=4, border_radius=16)
        pygame.draw.rect(surf, DEEP_RED, (w // 3, h - 26, w // 3, 26))
        self._set("boss_mothership", surf)

    def _build_boss_omega(self) -> None:
        if self._get("boss_omega") is not None:
            return
        w, h = 196, 116
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.polygon(surf, CHARCOAL, [(0, h // 2), (40, h // 3), (34, 3 * h // 4)])
        pygame.draw.ellipse(surf, ORANGE, (20, 10, w - 40, h - 20))
        pygame.draw.ellipse(surf, GOLD, (36, 22, w - 80, h - 50))
        pygame.draw.circle(surf, WHITE, (w - 50, h // 3), 16)
        pygame.draw.circle(surf, CHARCOAL, (w - 44, h // 3), 8)
        pygame.draw.polygon(surf, GOLD, [(w // 3, h // 2), (w // 4, 10), (w // 2, h // 3)])
        self._set("boss_omega", surf)

    def _build_arrow(self, name: str, shaft_color: Tuple[int, int, int], head_color: Tuple[int, int, int],
                     width: int) -> None:
        if self._get(name) is not None:
            return
        length = 90 if name != "arrow_standard" else 70
        surf = pygame.Surface((length, width * 4), pygame.SRCALPHA)
        cx = width * 2
        # Shaft
        pygame.draw.line(surf, shaft_color, (10, cx), (length - 14, cx), width)
        # Fletching
        pygame.draw.polygon(surf, DEEP_RED, [(10, cx), (22, cx - 8), (22, cx + 8)])
        # Head
        pygame.draw.polygon(surf, head_color, [(length - 14, cx), (length - 4, cx - 8), (length - 4, cx + 8)])
        self._set(name, surf)

    def _build_slingshot(self) -> None:
        if self._get("slingshot") is not None:
            return
        w, h = 120, 160
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.line(surf, CHARCOAL, (20, 30), (100, 30), 10)
        pygame.draw.line(surf, CHARCOAL, (60, 30), (60, 150), 16)
        pygame.draw.ellipse(surf, GRAY, (50, 20, 20, 20))
        self._set("slingshot", surf)

    def _build_powerup(self) -> None:
        if self._get("powerup") is not None:
            return
        w, h = 36, 36
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.circle(surf, PURPLE, (w // 2, h // 2), 16)
        pygame.draw.circle(surf, WHITE, (w // 2, h // 2), 9)
        self._set("powerup", surf)

    def get(self, name: str) -> Optional[pygame.Surface]:
        return self._get(name)

    def get_rotated(self, name: str, angle: float) -> Optional[pygame.Surface]:
        """Return a sprite rotated by a given angle (radians). Caches results."""
        surf = self._get(name)
        if surf is None:
            return None
        key = f"{name}_rot_{int(math.degrees(angle))}"
        cached = self._get(key)
        if cached is not None:
            return cached
        rotated = pygame.transform.rotate(surf, -math.degrees(angle))
        self._set(key, rotated)
        return rotated

    def get_scaled(self, name: str, width: int, height: int) -> Optional[pygame.Surface]:
        """Return a sprite scaled to a specific size. Caches results."""
        key = f"{name}_sc_{width}x{height}"
        cached = self._get(key)
        if cached is not None:
            return cached
        surf = self._get(name)
        if surf is None:
            return None
        scaled = pygame.transform.scale(surf, (width, height))
        self._set(key, scaled)
        return scaled
