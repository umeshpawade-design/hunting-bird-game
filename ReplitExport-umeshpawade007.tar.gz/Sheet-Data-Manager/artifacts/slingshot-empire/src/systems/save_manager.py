"""JSON-based profile save/load with validation, backups, and error handling."""

from __future__ import annotations

import json
import os
import shutil
from dataclasses import dataclass
from typing import Optional, Dict, Any

from config import PlayerProfile, WEAPONS


class SaveManager:
    """Handles player profile persistence."""

    def __init__(self, save_path: str = "player_data.json") -> None:
        self.save_path = save_path
        self._profiles: Dict[str, Any] = {}
        self._load_all()

    def _backup_path(self) -> str:
        return self.save_path + ".backup"

    def _load_all(self) -> None:
        if not os.path.exists(self.save_path):
            self._profiles = {}
            return
        try:
            with open(self.save_path, "r", encoding="utf-8") as f:
                self._profiles = json.load(f)
            if not isinstance(self._profiles, dict):
                self._profiles = {}
        except Exception:
            # Try loading from backup if main file is corrupt
            backup = self._backup_path()
            if os.path.exists(backup):
                try:
                    with open(backup, "r", encoding="utf-8") as f:
                        self._profiles = json.load(f)
                except Exception:
                    self._profiles = {}
            else:
                self._profiles = {}

    def save_profile(self, profile: PlayerProfile) -> None:
        clean_name = profile.name.strip()
        if not clean_name:
            return

        self._profiles[clean_name] = {
            "current_level": profile.current_level,
            "score": profile.score,
            "coins": profile.coins,
            "lives": profile.lives,
            "max_hp": profile.max_hp,
            "current_hp": profile.current_hp,
            "plasma_qty": profile.plasma_qty,
            "ballista_qty": profile.ballista_qty,
            "difficulty": profile.difficulty,
        }
        self._write()

    def _write(self) -> None:
        try:
            # Write to a temp file first, then replace to avoid corrupt saves
            tmp_path = self.save_path + ".tmp"
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(self._profiles, f, indent=2)
            if os.path.exists(self.save_path):
                shutil.copy2(self.save_path, self._backup_path())
            shutil.move(tmp_path, self.save_path)
        except Exception:
            pass

    def load_profile(self, name: str) -> Optional[PlayerProfile]:
        clean_name = name.strip()
        if clean_name not in self._profiles:
            return None
        data = self._profiles[clean_name]
        try:
            return PlayerProfile(
                name=clean_name,
                current_level=max(1, int(data.get("current_level", 1))),
                score=max(0, int(data.get("score", 0))),
                coins=max(0, int(data.get("coins", 0))),
                lives=max(0, int(data.get("lives", 15))),
                max_hp=max(1, int(data.get("max_hp", 100))),
                current_hp=max(0, int(data.get("current_hp", 100))),
                plasma_qty=max(0, int(data.get("plasma_qty", 5))),
                ballista_qty=max(0, int(data.get("ballista_qty", 5))),
                difficulty=data.get("difficulty", "MEDIUM"),
            )
        except Exception:
            return None

    def apply_profile_to_weapons(self, profile: PlayerProfile) -> None:
        WEAPONS["PLASMA"]["qty"] = max(0, profile.plasma_qty)
        WEAPONS["BALLISTA"]["qty"] = max(0, profile.ballista_qty)
