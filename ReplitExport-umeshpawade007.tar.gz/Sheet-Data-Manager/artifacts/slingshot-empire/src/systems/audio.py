"""Procedural audio generation and sound manager.

Uses pure Python + math to avoid heavy dependencies on Android. No external
sound files are required.
"""

from __future__ import annotations

import math
import array
from typing import Optional, Dict
import pygame

SAMPLE_RATE = 22050


def _make_waveform(duration: float, freq_func, amplitude: float = 0.5) -> array.array:
    """Generate a mono int16 waveform with a time-varying frequency."""
    n_samples = int(SAMPLE_RATE * duration)
    samples = array.array("h")
    for i in range(n_samples):
        t = i / SAMPLE_RATE
        freq = freq_func(t)
        sample = int(math.sin(2 * math.pi * freq * t) * 32767 * amplitude)
        samples.append(sample)
    return samples


def _constant_freq(freq: float) -> callable:
    return lambda t: freq


def _sweep(start: float, end: float, duration: float) -> callable:
    return lambda t: start + (end - start) * (t / duration)


def _arpeggio(notes, note_duration: float, amplitude: float = 0.4) -> array.array:
    total = array.array("h")
    samples_per_note = int(SAMPLE_RATE * note_duration)
    for note in notes:
        for i in range(samples_per_note):
            t = i / SAMPLE_RATE
            sample = int(math.sin(2 * math.pi * note * t) * 32767 * amplitude)
            total.append(sample)
    return total


class AudioManager:
    """Owns all generated sound effects and background music."""

    def __init__(self, enabled: bool = True) -> None:
        self.enabled = enabled
        self.sounds: Dict[str, Optional[pygame.mixer.Sound]] = {}
        self.music: Optional[pygame.mixer.Sound] = None
        self.music_channel: Optional[pygame.mixer.Channel] = None
        self._init_audio()
        self._generate_sounds()
        self._generate_music()

    def _init_audio(self) -> None:
        if not self.enabled:
            return
        try:
            pygame.mixer.init(
                frequency=SAMPLE_RATE,
                size=-16,
                channels=1,  # Mono reduces CPU and memory; mixer upmixes on device
                buffer=1024,  # Larger buffer avoids crackling on mobile
            )
        except Exception:
            self.enabled = False

    def _generate_sounds(self) -> None:
        if not self.enabled:
            return

        # Shoot: descending chirp
        self.sounds["shoot"] = self._array_to_sound(
            _make_waveform(0.12, _sweep(1200, 300, 0.12), 0.4)
        )

        # Hit: low thud
        self.sounds["hit"] = self._array_to_sound(
            _make_waveform(0.15, _constant_freq(140), 0.8)
        )

        # Alpha / powerup: happy arpeggio
        self.sounds["alpha"] = self._array_to_sound(
            _arpeggio([523.25, 659.25, 783.99, 1046.50], 0.06, 0.4)
        )
        self.sounds["powerup"] = self._array_to_sound(
            _arpeggio([523.25, 659.25, 783.99, 1046.50], 0.06, 0.4)
        )

        # Game over: descending sad notes
        self.sounds["gameover"] = self._array_to_sound(
            _arpeggio([392.00, 349.23, 311.13, 196.00], 0.25, 0.5)
        )

    def _generate_music(self) -> None:
        if not self.enabled:
            return
        notes = [110.0, 110.0, 130.81, 146.83, 110.0, 110.0, 164.81, 146.83]
        duration = 0.22
        samples_per_note = int(SAMPLE_RATE * duration)
        music = array.array("h")
        for note in notes:
            for i in range(samples_per_note):
                t = i / SAMPLE_RATE
                sample = int(math.sin(2 * math.pi * note * t) * 32767 * 0.2)
                music.append(sample)
        self.music = self._array_to_sound(music)
        self.music_channel = pygame.mixer.Channel(7)

    @staticmethod
    def _array_to_sound(data: array.array) -> Optional[pygame.mixer.Sound]:
        try:
            return pygame.mixer.Sound(buffer=data)
        except Exception:
            return None

    def play(self, name: str) -> None:
        if not self.enabled:
            return
        sound = self.sounds.get(name)
        if sound is None:
            return
        try:
            sound.play()
        except Exception:
            pass

    def start_music(self) -> None:
        if not self.enabled or self.music is None or self.music_channel is None:
            return
        try:
            if not self.music_channel.get_busy():
                self.music_channel.play(self.music, loops=-1)
        except Exception:
            pass

    def pause_music(self) -> None:
        if self.music_channel is not None and self.music_channel.get_busy():
            try:
                self.music_channel.pause()
            except Exception:
                pass

    def resume_music(self) -> None:
        if self.music_channel is not None:
            try:
                self.music_channel.unpause()
            except Exception:
                pass

    def stop_music(self) -> None:
        if self.music_channel is not None:
            try:
                self.music_channel.stop()
            except Exception:
                pass

    def set_volume(self, volume: float) -> None:
        if not self.enabled:
            return
        volume = max(0.0, min(1.0, volume))
        for sound in self.sounds.values():
            if sound is not None:
                sound.set_volume(volume)
        if self.music is not None:
            self.music.set_volume(volume * 0.5)
