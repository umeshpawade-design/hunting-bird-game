"""Physics, collision detection, and gameplay logic systems."""

from __future__ import annotations

import math
import random
from typing import List, Optional
import pygame

from config import (
    SETTINGS, MAX_BIRDS_ON_SCREEN, WEAPONS, DIFFICULTY_SETTINGS, MAX_COMBO_TIME,
    MAX_COMBO_MULTIPLIER, calculate_invasion_target, Objective, ORANGE, GOLD,
)
from entities.bird import Bird
from entities.boss import Boss, BossProjectile
from entities.arrow import Arrow
from entities.particle import ParticleSystem
from utils.helpers import screen_shake_offset
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from systems.vibration import VibrationManager


class GamePhysics:
    """Encapsulates movement, collision, spawning, and damage resolution."""

    def __init__(self, vibration: Optional[VibrationManager] = None) -> None:
        self.birds: List[Bird] = []
        self.arrows: List[Arrow] = []
        self.boss_projectiles: List[BossProjectile] = []
        self.powerups: List[dict] = []
        self.boss = Boss()
        self.particles = ParticleSystem()
        self.vibration = vibration

    def clear(self) -> None:
        self.birds.clear()
        self.arrows.clear()
        self.boss_projectiles.clear()
        self.powerups.clear()
        self.boss = Boss()
        self.particles.clear()

    def spawn_birds(self, level: int, count: int = MAX_BIRDS_ON_SCREEN, offscreen: bool = False) -> None:
        for _ in range(count):
            self.birds.append(Bird(level, offscreen=offscreen))

    def update_birds(self, dt: float, state) -> None:
        if self.boss.active:
            return
        for bird in self.birds:
            bird.update(dt)
            if bird.x > SETTINGS.width + 80:
                bird.respawn(state.level)

    def update_boss(self, dt: float, global_time: float, state) -> None:
        if not self.boss.active:
            return
        new_projs = self.boss.update(dt, global_time, state.level)
        self.boss_projectiles.extend(new_projs)

    def update_arrows(self, dt: float) -> None:
        for arrow in self.arrows:
            arrow.update(dt, self.particles)
        self.arrows = [a for a in self.arrows if a.active]

    def update_boss_projectiles(self, dt: float, slingshot_hitbox: pygame.Rect,
                                state) -> None:
        diff_dmg = DIFFICULTY_SETTINGS[state.difficulty]["dmg_mod"]
        for proj in self.boss_projectiles:
            proj.update(dt)
            if not proj.active:
                continue
            if proj.get_rect().colliderect(slingshot_hitbox):
                state.current_hp = max(0, state.current_hp - diff_dmg)
                state.shake_timer = 0.20
                state.shake_intensity = 4
                self.particles.spawn_burst(proj.x, proj.y, ORANGE, 12)
                proj.active = False
        self.boss_projectiles = [p for p in self.boss_projectiles if p.active]

    def update_powerups(self, dt: float, state) -> None:
        sx = SETTINGS.slingshot_x
        sy = SETTINGS.slingshot_y
        collect_rect = pygame.Rect(sx - 90, sy - 30, 180, 160)
        for pup in self.powerups:
            pup["y"] += 220 * dt
            dist = math.hypot(sx - pup["x"], sy - pup["y"])
            if dist < 350:
                magnet = 480 * dt
                if pup["x"] < sx:
                    pup["x"] += magnet
                elif pup["x"] > sx:
                    pup["x"] -= magnet
                if pup["y"] < sy:
                    pup["y"] += magnet * 0.5
            if collect_rect.collidepoint(pup["x"], pup["y"]):
                state.triple_shot_timer = 7.0
                # Remove after collection handled outside
                pup["active"] = False
            elif pup["y"] > SETTINGS.height:
                pup["active"] = False
        self.powerups = [p for p in self.powerups if p.get("active", True)]

    def update_particles(self, dt: float) -> None:
        self.particles.update(dt)

    def check_collisions(self, state) -> None:
        if self.boss.active:
            self._check_boss_collisions(state)
        else:
            self._check_bird_collisions(state)

    def _check_boss_collisions(self, state) -> None:
        boss_rect = self.boss.get_rect()
        for arrow in self.arrows:
            if not arrow.active:
                continue
            if arrow.get_rect().colliderect(boss_rect):
                self.particles.spawn_burst(arrow.x, arrow.y, GOLD, 15)
                arrow.active = False

                damage = WEAPONS[arrow.weapon_type]["damage"]
                died, hp_gain = self.boss.take_damage(damage)
                state.shake_timer = 0.15
                state.shake_intensity = 4
                if self.vibration is not None:
                    self.vibration.medium()
                if hp_gain > 0:
                    state.current_hp = min(state.max_hp, state.current_hp + hp_gain)

                if died:
                    if self.vibration is not None:
                        self.vibration.heavy()
                    if self.boss.wave_index < self.boss.total_waves:
                        # Clear lingering projectiles before next wave starts
                        self.boss_projectiles.clear()
                        self.arrows.clear()
                        self.boss.trigger(state.level, state.difficulty, self.boss.wave_index + 1)
                    else:
                        self._complete_boss_level(state)
                return  # Only one arrow can hit the boss per frame

    def _complete_boss_level(self, state) -> None:
        self.boss.active = False
        state.score += 150
        state.level_score_tracker = 0
        state.lives += 10
        state.coins += 15
        state.current_hp = min(state.max_hp, state.current_hp + 20)
        WEAPONS["PLASMA"]["qty"] += 3
        WEAPONS["BALLISTA"]["qty"] += 2
        state.selected_weapon = "STANDARD"
        state.level += 1

        if state.level >= 100:
            state.level = 100
            return

        state.level_up_banner_time = 2.0
        state.points_for_level_up = calculate_invasion_target(state.level)
        self.boss_projectiles.clear()
        self.spawn_birds(state.level, MAX_BIRDS_ON_SCREEN, offscreen=False)

    def _check_bird_collisions(self, state) -> None:
        for arrow in self.arrows:
            if not arrow.active:
                continue
            arrow_rect = arrow.get_rect()
            for bird in self.birds:
                if not bird.active:
                    continue
                if arrow_rect.colliderect(bird.get_rect()):
                    self.particles.spawn_burst(arrow.x, arrow.y, WEAPONS[arrow.weapon_type]["color"], 12)
                    arrow.active = False

                    # Start / grow combo
                    if state.combo_multiplier < MAX_COMBO_MULTIPLIER:
                        state.combo_multiplier += 1
                    state.combo_meter = MAX_COMBO_TIME

                    if bird.is_golden:
                        state.score += 20
                        state.level_score_tracker += 1
                        state.coins += 3
                        self.powerups.append({"x": bird.x + bird.w / 2, "y": bird.y + bird.h / 2, "active": True})
                        if self.vibration is not None:
                            self.vibration.heavy()
                    elif bird.is_alpha:
                        state.score += 15 * state.combo_multiplier
                        state.level_score_tracker += 1
                        state.coins += 3
                        self.particles.add_shockwave(bird.x + bird.w / 2, bird.y + bird.h / 2)
                        if self.vibration is not None:
                            self.vibration.medium()
                    else:
                        state.score += 5 * state.combo_multiplier
                        state.level_score_tracker += 1
                        state.coins += 1
                        if self.vibration is not None:
                            self.vibration.light()

                    state.current_hp = min(state.max_hp, state.current_hp + 1)
                    state.shake_timer = 0.12
                    state.shake_intensity = 3
                    self.check_objective(state)
                    bird.respawn(state.level)
                    break

    def check_objective(self, state, increment: int = 1) -> None:
        if self.boss.active:
            return
        state.objective.current += increment
        if state.objective.current >= state.objective.target:
            state.lives += 5
            WEAPONS["PLASMA"]["qty"] += 2
            WEAPONS["BALLISTA"]["qty"] += 1
            state.objective.reset()

    def check_level_up(self, state) -> None:
        if self.boss.active:
            return
        if state.level_score_tracker >= state.points_for_level_up:
            self.boss.trigger(state.level, state.difficulty, wave_index=1)
            self.birds.clear()

    def is_ammo_depleted(self, state) -> bool:
        standard_ok = state.lives > 0
        plasma_ok = WEAPONS["PLASMA"]["qty"] > 0
        ballista_ok = WEAPONS["BALLISTA"]["qty"] > 0
        return not (standard_ok or plasma_ok or ballista_ok)

    def get_shake_offset(self, state) -> tuple:
        return screen_shake_offset(state.shake_timer, state.shake_intensity)
