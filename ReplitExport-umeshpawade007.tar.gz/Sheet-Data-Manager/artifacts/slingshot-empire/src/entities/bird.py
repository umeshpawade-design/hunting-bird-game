"""Enemy bird entity: normal, alpha, and golden variants."""

from __future__ import annotations

import random
import math
import pygame
from typing import TYPE_CHECKING, Optional

from config import (
    SETTINGS, BIRD_CYAN, BIRD_LIGHT_CYAN, BIRD_NAVY_TAIL, ALPHA_BLUE, ALPHA_GLOW,
    GOLD, WHITE, ORANGE, CHARCOAL, COIN_VISIBILITY_COLOR,
)
from utils.helpers import draw_drop_shadow

if TYPE_CHECKING:
    from systems.sprite_atlas import SpriteAtlas


class Bird:
    __slots__ = ("x", "y", "speed", "w", "h", "is_alpha", "is_golden", "wing_phase", "active")

    def __init__(self, level: int, offscreen: bool = False) -> None:
        self.active = True
        rand = random.random()
        self.is_golden = rand < 0.08
        self.is_alpha = (not self.is_golden) and rand < 0.23

        self.w = 98 if (self.is_alpha or self.is_golden) else 88
        self.h = 58 if (self.is_alpha or self.is_golden) else 50

        level_mod = 1.0 + (level - 1) * 0.015
        base_min = 185.0 * level_mod
        base_max = 295.0 * level_mod
        self.speed = random.uniform(base_min, base_max)

        start_x = random.randint(-250, -90) if not offscreen else random.randint(-500, 0)
        self.x = float(start_x)
        max_y = max(120, int(SETTINGS.height * 0.45))
        self.y = float(random.randint(80, max_y))
        self.wing_phase = random.uniform(0, 5)

    def update(self, dt: float) -> None:
        if not self.active:
            return
        self.x += self.speed * dt
        if self.x > SETTINGS.width + 80:
            self.respawn()

    def respawn(self, level: int = 1) -> None:
        """Replace this bird with a freshly spawned one."""
        self.__init__(level, offscreen=True)

    def get_rect(self) -> pygame.Rect:
        return pygame.Rect(self.x, self.y, self.w, self.h)

    def draw(self, surface: pygame.Surface, global_time: float, atlas: Optional[SpriteAtlas] = None) -> None:
        if not self.active:
            return

        # Perspective scale: birds higher up are slightly smaller
        perspective = 1.0
        if SETTINGS.enable_perspective:
            perspective = 0.88 + 0.24 * (self.y / SETTINGS.height)

        w = int(self.w * perspective)
        h = int(self.h * perspective)
        x = int(self.x)
        y = int(self.y)

        # Drop shadow for 3D floating effect
        draw_drop_shadow(surface, x + w // 2, y + h // 2, w, h, alpha=70, blur=4)

        if atlas is not None:
            name = "bird_golden" if self.is_golden else ("bird_alpha" if self.is_alpha else "bird_normal")
            sprite = atlas.get_scaled(name, w, h)
            if sprite is not None:
                surface.blit(sprite, (x, y))
                return

        # Fallback procedural drawing
        flap = math.sin(global_time * 14 + self.wing_phase)
        main_color = GOLD if self.is_golden else (ALPHA_BLUE if self.is_alpha else BIRD_CYAN)
        light_shade = WHITE if self.is_golden else (ALPHA_GLOW if self.is_alpha else BIRD_LIGHT_CYAN)

        if self.is_alpha or self.is_golden:
            pygame.draw.ellipse(surface, light_shade, (x - 5, y - 5, w + 10, h + 10), 2)

        pygame.draw.polygon(surface, BIRD_NAVY_TAIL, [
            (x, y + h // 2), (x - 20, y + h // 4), (x - 15, y + int(h * 0.75))
        ])
        pygame.draw.ellipse(surface, main_color, (x, y + 4, int(w * 0.75), h - 6))
        pygame.draw.ellipse(surface, WHITE, (x + int(w * 0.45), y, int(w * 0.45), h - 2))

        wing_joint_x = x + int(w * 0.42)
        wing_joint_y = y + int(h * 0.4)
        for i in range(6):
            angle_offset = math.radians((i - 3) * 12)
            wing_len = int(h * 1.2) - (i * 3)
            end_x = wing_joint_x + math.sin(angle_offset) * (wing_len * 0.4)
            end_y = wing_joint_y + flap * (wing_len * math.cos(angle_offset))
            pygame.draw.polygon(surface, light_shade if i % 2 == 0 else main_color, [
                (wing_joint_x, wing_joint_y), (int(end_x), int(end_y)), (int(end_x - 12), int(end_y + 4))
            ])

        pygame.draw.circle(surface, CHARCOAL, (x + w - 22, y + int(h * 0.35)), 4)
        pygame.draw.polygon(surface, ORANGE, [
            (x + w - 8, y + int(h * 0.35)), (x + w + 14, y + int(h * 0.42)), (x + w - 10, y + int(h * 0.55))
        ])
