"""Player arrow / projectile entity and slingshot physics."""

from __future__ import annotations

import math
from typing import Tuple, TYPE_CHECKING, Optional
import pygame

from config import SETTINGS, CHARCOAL, DEEP_RED, GOLD, NEON_CYAN, WEAPONS
from entities.particle import ParticleSystem

if TYPE_CHECKING:
    from systems.sprite_atlas import SpriteAtlas


class Arrow:
    __slots__ = ("x", "y", "dx", "dy", "weapon_type", "active")

    def __init__(self, x: float, y: float, angle: float, velocity: float, weapon_type: str) -> None:
        self.x = x
        self.y = y
        self.dx = math.cos(angle) * velocity
        self.dy = math.sin(angle) * velocity
        self.weapon_type = weapon_type
        self.active = True

    def update(self, dt: float, particles: ParticleSystem) -> None:
        if not self.active:
            return
        self.x += self.dx * dt
        self.y += self.dy * dt

        # Add weapon trail
        if self.weapon_type != "STANDARD":
            particles.add_weapon_trail(self.x, self.y, self.weapon_type)

        # Bounds check
        margin = 40
        if (self.x < -margin or self.x > SETTINGS.width + margin or
            self.y < -margin or self.y > SETTINGS.height + margin):
            self.active = False

    def get_rect(self) -> pygame.Rect:
        return pygame.Rect(self.x - 12, self.y - 12, 24, 24)

    def draw(self, surface: pygame.Surface, atlas: Optional[SpriteAtlas] = None) -> None:
        if not self.active:
            return

        if atlas is not None:
            name = f"arrow_{self.weapon_type.lower()}"
            sprite = atlas.get(name)
            if sprite is not None:
                angle = math.atan2(self.dy, self.dx)
                rotated = atlas.get_rotated(name, angle)
                if rotated is not None:
                    rect = rotated.get_rect(center=(int(self.x), int(self.y)))
                    surface.blit(rotated, rect)
                    return

        draw_arrow(surface, self.x, self.y, self.dx, self.dy, self.weapon_type)


def draw_arrow(surface: pygame.Surface, x: float, y: float, dx: float, dy: float,
               weapon_type: str, is_ready: bool = False,
               atlas: Optional[SpriteAtlas] = None) -> None:
    """Draw a single arrow or slingshot bolt."""
    if is_ready:
        angle = -math.pi / 2
    else:
        angle = math.atan2(dy, dx)

    if atlas is not None:
        name = f"arrow_{weapon_type.lower()}"
        sprite = atlas.get(name)
        if sprite is not None:
            rotated = atlas.get_rotated(name, angle)
            if rotated is not None:
                rect = rotated.get_rect(center=(int(x), int(y)))
                surface.blit(rotated, rect)
                return

    length = 85 if weapon_type != "STANDARD" else 65
    tip_x = x + math.cos(angle) * 5
    tip_y = y + math.sin(angle) * 5
    tail_x = x - math.cos(angle) * length
    tail_y = y - math.sin(angle) * length

    color = WEAPONS.get(weapon_type, WEAPONS["STANDARD"])["color"]

    # Body
    pygame.draw.line(surface, color, (int(tip_x), int(tip_y)), (int(tail_x), int(tail_y)),
                     7 if weapon_type != "STANDARD" else 5)

    # Fletching (feathers)
    f_angle1 = angle + math.radians(150)
    f_angle2 = angle - math.radians(150)
    f_length = 25 if weapon_type != "STANDARD" else 20
    pygame.draw.line(surface, DEEP_RED, (int(tail_x), int(tail_y)),
                     (int(tail_x + math.cos(f_angle1) * f_length), int(tail_y + math.sin(f_angle1) * f_length)), 4)
    pygame.draw.line(surface, DEEP_RED, (int(tail_x), int(tail_y)),
                     (int(tail_x + math.cos(f_angle2) * f_length), int(tail_y + math.sin(f_angle2) * f_length)), 4)

    # Arrowhead
    tip_angle1 = angle + math.radians(165)
    tip_angle2 = angle - math.radians(165)
    t_length = 22 if weapon_type != "STANDARD" else 16
    head_color = NEON_CYAN if weapon_type == "PLASMA" else GOLD
    points = [
        (tip_x, tip_y),
        (tip_x + math.cos(tip_angle1) * t_length, tip_y + math.sin(tip_angle1) * t_length),
        (tip_x + math.cos(tip_angle2) * t_length, tip_y + math.sin(tip_angle2) * t_length),
    ]
    pygame.draw.polygon(surface, head_color, points)


def draw_slingshot_base(surface: pygame.Surface, color: Tuple[int, int, int],
                        atlas: Optional[SpriteAtlas] = None) -> None:
    """Draw the stationary slingshot base."""
    if atlas is not None:
        sprite = atlas.get("slingshot")
        if sprite is not None:
            sx = int(SETTINGS.slingshot_x - sprite.get_width() // 2)
            sy = int(SETTINGS.slingshot_y - sprite.get_height() // 3)
            surface.blit(sprite, (sx, sy))
            return

    sx = int(SETTINGS.slingshot_x)
    sy = int(SETTINGS.slingshot_y)
    pygame.draw.line(surface, color, (sx - 40, sy + 30), (sx + 40, sy + 30), 8)
    pygame.draw.line(surface, color, (sx, sy + 30), (sx, sy + 130), 12)


def compute_shot(drag_start_x: float, drag_start_y: float, mx: float, my: float,
                 weapon_type: str) -> Tuple[float, float, float]:
    """Return (angle, velocity, shot_count) from a drag vector."""
    dx = drag_start_x - mx
    dy = drag_start_y - my
    dist = math.hypot(dx, dy)
    if dist < 20:
        return 0.0, 0.0, 0

    vel_mod = WEAPONS[weapon_type]["vel_mod"]
    velocity = min(dist * 5.5 * vel_mod, 1800.0)
    angle = math.atan2(dy, dx)

    return angle, velocity, 1
