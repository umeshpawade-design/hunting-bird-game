"""Boss entity with back-to-back wave mechanics and projectiles."""

from __future__ import annotations

import random
import math
import pygame
from typing import TYPE_CHECKING, Optional

from config import (
    SETTINGS, BOSS_TYPES_POOL, CHARCOAL, DEEP_RED, ORANGE, GOLD, PURPLE, NEON_CYAN,
    NEON_YELLOW, GRAY, MIDNIGHT_DARK, WHITE, calculate_boss_waves, DIFFICULTY_SETTINGS,
)
from utils.helpers import draw_drop_shadow

if TYPE_CHECKING:
    from systems.sprite_atlas import SpriteAtlas


class BossProjectile:
    __slots__ = ("x", "y", "speed_x", "speed_y", "active")

    def __init__(self, x: float, y: float, speed_x: float, speed_y: float) -> None:
        self.x = x
        self.y = y
        self.speed_x = speed_x
        self.speed_y = speed_y
        self.active = True

    def update(self, dt: float) -> None:
        self.x += self.speed_x * dt
        self.y += self.speed_y * dt
        if self.y > SETTINGS.height + 20 or self.x < -50 or self.x > SETTINGS.width + 50:
            self.active = False

    def get_rect(self) -> pygame.Rect:
        return pygame.Rect(self.x - 10, self.y - 10, 20, 20)

    def draw(self, surface: pygame.Surface) -> None:
        pygame.draw.circle(surface, ORANGE, (int(self.x), int(self.y)), 11)
        pygame.draw.circle(surface, GOLD, (int(self.x), int(self.y)), 6)


class Boss:
    __slots__ = (
        "x", "y", "w", "h", "speed_x", "direction", "max_hp", "current_hp",
        "active", "base_y", "shoot_cooldown", "kind", "wave_index", "total_waves",
        "next_damage_threshold",
    )

    def __init__(self) -> None:
        self.x = 0.0
        self.y = 150.0
        self.w = 196
        self.h = 116
        self.speed_x = 250.0
        self.direction = 1
        self.max_hp = 5
        self.current_hp = 5
        self.active = False
        self.base_y = 150.0
        self.shoot_cooldown = 0.0
        self.kind = "PHOENIX"
        self.wave_index = 1
        self.total_waves = 1
        self.next_damage_threshold = 0.0

    def _sprite_name(self) -> str:
        mapping = {
            "PHOENIX": "boss_phoenix",
            "DRONE": "boss_drone",
            "UFO": "boss_ufo",
            "MOTHERSHIP": "boss_mothership",
            "OMEGA": "boss_omega",
        }
        return mapping.get(self.kind, "boss_phoenix")

    def trigger(self, level: int, difficulty: str, wave_index: int = 1) -> None:
        self.active = True
        self.wave_index = wave_index
        self.total_waves = calculate_boss_waves(level)
        self.kind = random.choice(BOSS_TYPES_POOL)

        if level <= 30:
            scale = 1.0 + (level / 30.0) * 0.35
        else:
            scale = 1.0 + (level / 100.0) * 0.20
        self.w = int(196 * scale)
        self.h = int(116 * scale)

        base_hp = 5 + level * 2
        if wave_index > 1:
            base_hp = int(base_hp * 1.3)
        diff_cfg = DIFFICULTY_SETTINGS[difficulty]
        self.max_hp = max(1, int(base_hp * diff_cfg["boss_hp_mod"]))
        self.current_hp = self.max_hp
        self.next_damage_threshold = float(self.max_hp)

        self.x = -200.0
        self.base_y = random.randint(150, 220)
        level_mod = 1.0 + (level - 1) * 0.02
        self.speed_x = (230.0 * level_mod) * diff_cfg["speed_mod"]
        self.shoot_cooldown = 1.0

    def update(self, dt: float, global_time: float, level: int) -> list:
        """Update boss movement and return new projectiles."""
        if not self.active:
            return []

        self.x += self.speed_x * self.direction * dt
        self.y = self.base_y + math.sin(global_time * 5) * 80.0

        if self.x > SETTINGS.width - self.w - 50 and self.direction == 1:
            self.direction = -1
        elif self.x < 50 and self.direction == -1:
            self.direction = 1

        self.shoot_cooldown -= dt
        new_projectiles = []
        if self.shoot_cooldown <= 0:
            cx = self.x + self.w // 2
            cy = self.y + self.h
            if 1 <= level <= 30:
                new_projectiles.append(BossProjectile(cx, cy, 0.0, 380.0 + level * 5))
            elif 31 <= level <= 60:
                new_projectiles.append(BossProjectile(cx - 20, cy, -40.0, 420.0))
                new_projectiles.append(BossProjectile(cx + 20, cy, 40.0, 420.0))
            elif 61 <= level <= 90:
                for offset in [-120.0, 0.0, 120.0]:
                    new_projectiles.append(BossProjectile(cx, cy, offset, 450.0))
            elif 91 <= level <= 100:
                dx = SETTINGS.slingshot_x - cx
                angle = math.atan2(SETTINGS.height, dx)
                spd = 460.0 + level * 2
                new_projectiles.append(BossProjectile(cx, cy, math.cos(angle) * spd, math.sin(angle) * spd))
                new_projectiles.append(BossProjectile(cx, cy, -math.cos(angle) * spd, math.sin(angle) * spd))
            self.shoot_cooldown = max(0.4, 1.2 - level * 0.01)
        return new_projectiles

    def take_damage(self, damage: int) -> Tuple[bool, int]:
        """Deal damage and return (is_dead, hp_to_recover_on_hit)."""
        self.current_hp -= damage
        hp_gain = 0
        if self.current_hp <= self.next_damage_threshold - (self.max_hp * 0.1):
            hp_gain = max(1, self.max_hp // 10)
            self.next_damage_threshold -= (self.max_hp * 0.1)
        if self.current_hp <= 0:
            self.current_hp = 0
            return True, hp_gain
        return False, hp_gain

    def get_rect(self) -> pygame.Rect:
        return pygame.Rect(self.x, self.y, self.w, self.h)

    def draw(self, surface: pygame.Surface, global_time: float, atlas: Optional[SpriteAtlas] = None) -> None:
        if not self.active:
            return

        perspective = 1.0
        if SETTINGS.enable_perspective:
            perspective = 0.92 + 0.16 * (self.y / SETTINGS.height)
        w = int(self.w * perspective)
        h = int(self.h * perspective)
        x = int(self.x)
        y = int(self.y)

        draw_drop_shadow(surface, x + w // 2, y + h // 2, w, h, alpha=100, blur=5)

        if atlas is not None:
            sprite = atlas.get_scaled(self._sprite_name(), w, h)
            if sprite is not None:
                surface.blit(sprite, (x, y))
                return

        # Fallback procedural drawing (minimal red/orange silhouette)
        pygame.draw.ellipse(surface, DEEP_RED, (x, y + h // 4, w, 3 * h // 4))
        pygame.draw.ellipse(surface, ORANGE, (x + w // 4, y, w // 2, h // 2))
        pygame.draw.circle(surface, WHITE, (x + w - 50, y + h // 3), 16)
        pygame.draw.circle(surface, CHARCOAL, (x + w - 44, y + h // 3), 8)
