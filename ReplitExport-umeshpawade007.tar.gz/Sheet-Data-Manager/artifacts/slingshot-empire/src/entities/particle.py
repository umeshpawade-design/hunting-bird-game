"""Particle, trail, and shockwave effects."""

from __future__ import annotations

import random
import math
from typing import List, Tuple
import pygame

from config import NEON_CYAN, DEEP_RED, ORANGE, GOLD, ALPHA_GLOW


class Particle:
    __slots__ = ("x", "y", "vx", "vy", "radius", "life", "max_life", "color")

    def __init__(self, x: float, y: float, color: Tuple[int, int, int], speed: float = 200.0,
                 radius: Tuple[int, int] = (3, 7)) -> None:
        self.x = x
        self.y = y
        angle = random.uniform(0, 2 * math.pi)
        speed_val = random.uniform(speed * 0.5, speed)
        self.vx = math.cos(angle) * speed_val
        self.vy = math.sin(angle) * speed_val
        self.radius = random.randint(*radius)
        self.max_life = 255.0
        self.life = 255.0
        self.color = color

    def update(self, dt: float) -> bool:
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.life -= dt * 450
        return self.life > 0


class WeaponTrail:
    __slots__ = ("x", "y", "vx", "vy", "color", "radius", "life", "max_life", "kind")

    def __init__(self, x: float, y: float, weapon_type: str) -> None:
        self.x = x
        self.y = y
        self.vx = random.uniform(-30, 30)
        self.vy = random.uniform(-30, 30)
        self.radius = random.randint(8, 16)
        self.max_life = 255.0
        self.life = 255.0
        self.kind = weapon_type
        if weapon_type == "PLASMA":
            self.color = NEON_CYAN
        elif weapon_type == "BALLISTA":
            self.color = random.choice([DEEP_RED, ORANGE, GOLD])
        else:
            self.color = GOLD

    def update(self, dt: float) -> bool:
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.life -= dt * 500
        return self.life > 0


class Shockwave:
    __slots__ = ("x", "y", "radius", "expansion_speed", "life", "max_life")

    def __init__(self, x: float, y: float, radius: float = 15.0,
                 expansion_speed: float = 480.0, life: float = 1.0) -> None:
        self.x = x
        self.y = y
        self.radius = radius
        self.expansion_speed = expansion_speed
        self.life = life
        self.max_life = life

    def update(self, dt: float) -> bool:
        self.radius += self.expansion_speed * dt
        self.life -= dt * 2.5
        return self.life > 0

    def draw(self, surface: pygame.Surface) -> None:
        pygame.draw.circle(surface, NEON_CYAN, (int(self.x), int(self.y)), int(self.radius), 3)


class ParticleSystem:
    """Aggregates all visual effects and manages their lifecycle."""

    # Max radius is 16 (weapon trails). Particle scratch surface is 2x that.
    _SCRATCH_SIZE = 64
    _SCRATCH_CENTER = 32

    def __init__(self) -> None:
        self.particles: List[Particle] = []
        self.trails: List[WeaponTrail] = []
        self.shockwaves: List[Shockwave] = []
        self._scratch = pygame.Surface((self._SCRATCH_SIZE, self._SCRATCH_SIZE), pygame.SRCALPHA)

    def clear(self) -> None:
        self.particles.clear()
        self.trails.clear()
        self.shockwaves.clear()

    def spawn_burst(self, x: float, y: float, color: Tuple[int, int, int], count: int = 15) -> None:
        for _ in range(count):
            self.particles.append(Particle(x, y, color))

    def add_weapon_trail(self, x: float, y: float, weapon_type: str) -> None:
        if weapon_type != "STANDARD":
            self.trails.append(WeaponTrail(x, y, weapon_type))

    def add_shockwave(self, x: float, y: float) -> None:
        self.shockwaves.append(Shockwave(x, y))

    def update(self, dt: float) -> None:
        self.particles = [p for p in self.particles if p.update(dt)]
        self.trails = [t for t in self.trails if t.update(dt)]
        self.shockwaves = [s for s in self.shockwaves if s.update(dt)]

    def _draw_soft_circle(self, surface: pygame.Surface, x: float, y: float,
                          radius: int, color: Tuple[int, int, int], alpha: int) -> None:
        """Draw a single alpha-blended circle using the shared scratch surface."""
        self._scratch.fill((0, 0, 0, 0))
        pygame.draw.circle(self._scratch, (*color, alpha),
                           (self._SCRATCH_CENTER, self._SCRATCH_CENTER), radius)
        # Blit only the used portion to avoid large transparent overdraw.
        surface.blit(self._scratch,
                     (int(x - radius), int(y - radius)),
                     (self._SCRATCH_CENTER - radius, self._SCRATCH_CENTER - radius,
                      radius * 2, radius * 2))

    def draw(self, surface: pygame.Surface) -> None:
        for p in self.particles:
            alpha = max(0, min(255, int(p.life)))
            self._draw_soft_circle(surface, p.x, p.y, p.radius, p.color, alpha)
        for t in self.trails:
            alpha = max(0, min(255, int(t.life)))
            self._draw_soft_circle(surface, t.x, t.y, t.radius, t.color, alpha)
        for s in self.shockwaves:
            s.draw(surface)
