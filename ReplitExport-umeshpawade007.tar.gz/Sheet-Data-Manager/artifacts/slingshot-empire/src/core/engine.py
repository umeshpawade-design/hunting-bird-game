"""Main game engine: state machine, main loop, rendering orchestration."""

from __future__ import annotations

import math
import random
import sys
import os
from typing import Optional, Tuple, List

import pygame

from config import (
    SETTINGS, update_settings_for_screen, STATE_MENU, STATE_READY, STATE_SHOP,
    STATE_PAUSE, STATE_GAMEOVER, STATE_VICTORY, GameStateData, PlayerProfile,
    WEAPONS, reset_weapons, DIFFICULTY_SETTINGS, MAX_BIRDS_ON_SCREEN,
    MAX_COMBO_TIME, MAX_COMBO_MULTIPLIER, calculate_invasion_target,
    SKY_TOP, SKY_BOTTOM, PURE_BLACK, SPACE_DARK, SPACE_NEBULA, RED_BLACK,
    CLOUD_SHADOW, CLOUD_WHITE, CHARCOAL, WHITE, GOLD, DEEP_RED, BRIGHT_GREEN,
    ORANGE, PURPLE, GRAY, BUTTON_HOVER, NEON_CYAN,
)
from systems.audio import AudioManager
from systems.save_manager import SaveManager
from systems.physics import GamePhysics
from systems.sprite_atlas import SpriteAtlas
from systems.vibration import VibrationManager
from systems.ads import AdManager
from entities.bird import Bird
from entities.arrow import Arrow, draw_arrow, draw_slingshot_base, compute_shot
from ui.widgets import Button, Label, TextInput, Panel
from ui.hud import HUD, draw_text
from utils.helpers import build_sky_gradient, clamp, lerp, screen_shake_offset, get_font, draw_drop_shadow


class Game:
    """Top-level game class that owns the main loop and all subsystems."""

    def __init__(self, width: Optional[int] = None, height: Optional[int] = None,
                 fullscreen: bool = True, headless: bool = False) -> None:
        self.headless = headless
        pygame.init()
        if not headless:
            pygame.display.init()

        self.audio = AudioManager(enabled=not headless)
        self.save_manager = SaveManager(save_path=SETTINGS.save_path)
        self.vibration = VibrationManager(enabled=SETTINGS.enable_vibration and not headless)
        self.ads = AdManager(enabled=SETTINGS.enable_ads)
        self.ads.initialize()

        self.physics = GamePhysics(vibration=self.vibration)
        self.state = GameStateData()
        self.hud = HUD()

        self.game_surface: Optional[pygame.Surface] = None
        self.sky_surface: Optional[pygame.Surface] = None
        self._nebula_surface: Optional[pygame.Surface] = None
        self.screen: Optional[pygame.Surface] = None

        # Camera / parallax tilt
        self._tilt_x = 0.0
        self._tilt_y = 0.0

        # Input state
        self.mx = 0
        self.my = 0
        self.touch_down = False
        self.touch_up = False
        self.is_dragging = False
        self.drag_start_x = 0.0
        self.drag_start_y = 0.0
        self.player_name = "Player 1"
        self.input_active = False

        # Menu UI
        self.name_input: Optional[TextInput] = None
        self.menu_buttons: List[Button] = []
        self.shop_buttons: List[Button] = []
        self.victory_button: Optional[Button] = None
        self.difficulty_buttons: List[Button] = []
        self._build_static_ui()

        # Clouds / stars
        self.clouds: List[dict] = []
        self.stars: List[dict] = []
        self._init_environment()

        # Set up display (must happen before sprite atlas convert_alpha)
        self._setup_display(width, height, fullscreen)
        self.clock = pygame.time.Clock()
        self.running = True

        # Sprite atlas after display init so external PNG overrides load correctly
        self.sprite_atlas = SpriteAtlas()

        # Start music on menu
        self.audio.start_music()
        pygame.key.start_text_input()

        # Show a banner ad on menu if ads are enabled
        self.ads.show_banner()

    def _setup_display(self, width: Optional[int], height: Optional[int], fullscreen: bool) -> None:
        if self.headless:
            return
        info = pygame.display.Info()
        if width is None or height is None:
            width = info.current_w
            height = info.current_h
        flags = pygame.FULLSCREEN | pygame.SCALED if fullscreen else pygame.RESIZABLE
        try:
            self.screen = pygame.display.set_mode((width, height), flags)
        except Exception:
            self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption("Slingshot Empire: Invasion Overdrive Pro")
        update_settings_for_screen(width, height)
        self._rebuild_cached_surfaces()

    def _rebuild_cached_surfaces(self) -> None:
        if self.headless:
            return
        self.game_surface = pygame.Surface((SETTINGS.width, SETTINGS.height))
        self.sky_surface = build_sky_gradient(SETTINGS.width, SETTINGS.height, SKY_TOP, SKY_BOTTOM)
        self._nebula_surface = pygame.Surface((340, 340), pygame.SRCALPHA)
        self.hud.update_layout()
        self._rebuild_static_ui_positions()

    def _build_static_ui(self) -> None:
        """Create buttons and inputs whose geometry depends on screen size."""
        cx = SETTINGS.width // 2
        cy = SETTINGS.height // 2

        # Menu
        self.name_input = TextInput(cx - 160, cy - 45, 320, 45, "NAME")
        self.name_input.text = self.player_name

        self.menu_buttons = [
            Button(cx - 160, 380, 320, 60, "START ASSAULT", BRIGHT_GREEN, BUTTON_HOVER, on_click=self._on_start),
            Button(cx - 160, 470, 320, 60, "QUIT GAME", DEEP_RED, (230, 100, 100), on_click=self._on_quit),
        ]
        self.difficulty_buttons = [
            Button(cx - 170, 305, 100, 45, "EASY", BRIGHT_GREEN, BUTTON_HOVER, WHITE, 16, on_click=lambda: self._set_difficulty("EASY")),
            Button(cx - 50, 305, 100, 45, "MEDIUM", ORANGE, BUTTON_HOVER, WHITE, 16, on_click=lambda: self._set_difficulty("MEDIUM")),
            Button(cx + 70, 305, 100, 45, "HARD", DEEP_RED, BUTTON_HOVER, WHITE, 16, on_click=lambda: self._set_difficulty("HARD")),
        ]

        # Shop / pause / gameover shared buttons
        self.shop_buttons = [
            Button(cx - 180, cy - 80, 360, 55, "", BRIGHT_GREEN, BUTTON_HOVER, WHITE, 18, on_click=self._buy_ammo),
            Button(cx - 180, cy - 10, 360, 55, "", PURPLE, (170, 40, 230), WHITE, 18, on_click=self._buy_hp),
            Button(cx - 180, cy + 60, 360, 55, "CLOSE ARMORY", DEEP_RED, (230, 100, 100), WHITE, 20, on_click=self._close_shop),
            Button(cx - 180, cy + 130, 360, 55, "EXIT TO MAIN MENU", GRAY, CHARCOAL, WHITE, 18, on_click=self._exit_to_menu),
        ]
        self.continue_button = Button(cx - 95, SETTINGS.height - 285, 190, 45, "CONTINUE", ORANGE, GOLD, WHITE, 16, on_click=self._resume_game)
        self.victory_button = Button(cx - 160, cy + 60, 320, 60, "RETURN TO MENU", BRIGHT_GREEN, BUTTON_HOVER, WHITE, 18, on_click=self._exit_to_menu)

    def _rebuild_static_ui_positions(self) -> None:
        """Reposition UI elements that depend on screen size."""
        cx = SETTINGS.width // 2
        cy = SETTINGS.height // 2
        self.continue_button.set_position(cx - 95, SETTINGS.height - 285)
        self.shop_buttons[0].set_position(cx - 180, cy - 80)
        self.shop_buttons[1].set_position(cx - 180, cy - 10)
        self.shop_buttons[2].set_position(cx - 180, cy + 60)
        self.shop_buttons[3].set_position(cx - 180, cy + 130)
        self.victory_button.set_position(cx - 160, cy + 60)
        # Main menu layout: clean vertical spacing, no overlap with title
        self.name_input.set_position(cx - 160, 165)
        for i, btn in enumerate(self.difficulty_buttons):
            btn.set_position(cx - 170 + i * 120, 305)
        for i, btn in enumerate(self.menu_buttons):
            if i == 0:
                btn.set_position(cx - 160, 380)
            else:
                btn.set_position(cx - 160, 470)

    def _init_environment(self) -> None:
        self.clouds.clear()
        for _ in range(5):
            self.clouds.append({
                "x": random.randint(0, max(100, SETTINGS.width)),
                "y": random.randint(20, max(40, SETTINGS.height // 3)),
                "speed": random.uniform(30.0, 80.0),
                "size": random.randint(40, 75),
            })
        self.stars.clear()
        for _ in range(50):
            self.stars.append({
                "x": random.randint(0, max(10, SETTINGS.width)),
                "y": random.randint(0, max(10, SETTINGS.height)),
                "brightness": random.randint(120, 255),
                "twinkle_speed": random.uniform(3.0, 6.0),
            })
        # 3D parallax background layers (far = slower, near = faster)
        self.parallax_layers: List[List[dict]] = []
        for layer_idx, count, depth in [(0, 40, 0.05), (1, 30, 0.12), (2, 20, 0.25)]:
            layer = []
            for _ in range(count):
                layer.append({
                    "x": random.randint(0, max(10, SETTINGS.width)),
                    "y": random.randint(0, max(10, SETTINGS.height)),
                    "brightness": random.randint(80 + layer_idx * 40, 255),
                    "twinkle_speed": random.uniform(2.0, 6.0),
                    "size": random.choice([1, 2, 3]) if layer_idx > 0 else 1,
                    "depth": depth,
                })
            self.parallax_layers.append(layer)

    def _set_difficulty(self, diff: str) -> None:
        self.state.difficulty = diff
        self.audio.play("alpha")

    def _on_start(self) -> None:
        self.player_name = self.name_input.get_value() or "Player 1"
        profile = self.save_manager.load_profile(self.player_name)
        if profile is not None:
            self.state.score = profile.score
            self.state.coins = profile.coins
            self.state.level = profile.current_level
            self.state.lives = profile.lives
            self.state.max_hp = profile.max_hp
            self.state.current_hp = profile.current_hp
            self.state.difficulty = profile.difficulty
            self.save_manager.apply_profile_to_weapons(profile)
            # Ensure physics is fresh and birds are spawned for the loaded profile
            self.physics.clear()
            self.physics.spawn_birds(self.state.level, MAX_BIRDS_ON_SCREEN, offscreen=False)
            self.state.objective.reset()
        else:
            self._reset_game()
        self.state.update_level_target()
        self.state.selected_weapon = "STANDARD"
        self.state.global_time = 0.0
        self.state.game_state = STATE_READY
        self.audio.play("shoot")

    def _on_quit(self) -> None:
        self.running = False

    def _reset_game(self) -> None:
        diff = self.state.difficulty  # preserve menu difficulty selection for new games
        self.state = GameStateData()
        self.state.difficulty = diff
        self.state.update_level_target()
        reset_weapons()
        self.physics.clear()
        self.physics.spawn_birds(self.state.level, MAX_BIRDS_ON_SCREEN, offscreen=False)
        self.state.selected_weapon = "STANDARD"
        self.audio.resume_music()

    def _buy_ammo(self) -> None:
        cost = 30 + (self.state.level - 1) * 10
        if self.state.coins >= cost:
            self.state.coins -= cost
            self.state.lives += 10
            self.audio.play("powerup")
            self._save()
            if self.state.game_state == STATE_GAMEOVER:
                self.state.game_state = STATE_READY
                self.audio.resume_music()
        else:
            self.audio.play("gameover")

    def _buy_hp(self) -> None:
        cost = 50 + (self.state.level - 1) * 15
        if self.state.coins >= cost:
            self.state.coins -= cost
            self.state.max_hp += 20
            self.state.current_hp = min(self.state.max_hp, self.state.current_hp + 40)
            self.audio.play("powerup")
            self._save()
            if self.state.game_state == STATE_GAMEOVER:
                self.state.game_state = STATE_READY
                self.audio.resume_music()
        else:
            self.audio.play("gameover")

    def _close_shop(self) -> None:
        if self.state.game_state != STATE_GAMEOVER:
            self.state.game_state = STATE_READY
            self.audio.play("shoot")
        else:
            self.audio.play("gameover")

    def _resume_game(self) -> None:
        if self.state.game_state != STATE_GAMEOVER:
            self.state.game_state = STATE_READY
            self.audio.play("shoot")

    def _exit_to_menu(self) -> None:
        self._save()
        self.state.game_state = STATE_MENU
        self.audio.play("alpha")
        self.audio.start_music()

    def _save(self) -> None:
        profile = PlayerProfile(
            name=self.player_name,
            score=self.state.score,
            coins=self.state.coins,
            current_level=self.state.level,
            lives=self.state.lives,
            max_hp=self.state.max_hp,
            current_hp=self.state.current_hp,
            plasma_qty=WEAPONS["PLASMA"]["qty"],
            ballista_qty=WEAPONS["BALLISTA"]["qty"],
            difficulty=self.state.difficulty,
        )
        self.save_manager.save_profile(profile)

    def _handle_events(self) -> None:
        self.touch_down = False
        self.touch_up = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

            elif event.type == pygame.VIDEORESIZE:
                self._setup_display(event.w, event.h, fullscreen=False)

            elif event.type == pygame.TEXTINPUT:
                if self.state.game_state == STATE_MENU and self.input_active:
                    self.name_input.handle_event(event)

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.running = False
                if self.state.game_state == STATE_MENU and self.input_active:
                    self.name_input.handle_event(event)

            elif event.type == pygame.MOUSEBUTTONDOWN or event.type == pygame.FINGERDOWN:
                self.touch_down = True
                if event.type == pygame.MOUSEBUTTONDOWN:
                    self.mx, self.my = event.pos
                else:
                    self.mx = int(event.x * SETTINGS.width)
                    self.my = int(event.y * SETTINGS.height)
                self._on_touch_down(self.mx, self.my)

            elif event.type == pygame.MOUSEBUTTONUP or event.type == pygame.FINGERUP:
                self.touch_up = True
                if event.type == pygame.MOUSEBUTTONUP:
                    self.mx, self.my = event.pos
                else:
                    self.mx = int(event.x * SETTINGS.width)
                    self.my = int(event.y * SETTINGS.height)
                self._on_touch_up(self.mx, self.my)

            elif event.type == pygame.MOUSEMOTION or event.type == pygame.FINGERMOTION:
                if event.type == pygame.MOUSEMOTION:
                    self.mx, self.my = event.pos
                else:
                    self.mx = int(event.x * SETTINGS.width)
                    self.my = int(event.y * SETTINGS.height)

        # Continuous touch state for dragging
        self.touch_down = self.touch_down or pygame.mouse.get_pressed()[0]

    def _on_touch_down(self, x: int, y: int) -> None:
        if self.state.game_state == STATE_MENU:
            if self.name_input.rect.collidepoint(x, y):
                self.input_active = True
                self.name_input.text = ""
            else:
                self.input_active = False
            return

        if self.state.game_state in (STATE_SHOP, STATE_PAUSE, STATE_GAMEOVER):
            return

        if self.state.game_state == STATE_READY:
            # Check weapon tabs first
            for i, tab in enumerate(self.hud.weapon_tabs):
                if tab.rect.collidepoint(x, y):
                    w_id = ["STANDARD", "PLASMA", "BALLISTA"][i]
                    if self.state.boss_active or w_id == "STANDARD":
                        if WEAPONS[w_id]["qty"] != -1 and WEAPONS[w_id]["qty"] <= 0:
                            return
                        self.state.selected_weapon = w_id
                        self.audio.play("alpha")
                    return

            # Start drag if we have ammo and health
            can_shoot = (self.state.lives > 0 or WEAPONS["PLASMA"]["qty"] > 0 or
                         WEAPONS["BALLISTA"]["qty"] > 0) and self.state.current_hp > 0
            if can_shoot:
                self.is_dragging = True
                self.drag_start_x = x
                self.drag_start_y = y

    def _on_touch_up(self, x: int, y: int) -> None:
        if self.is_dragging and self.state.game_state == STATE_READY:
            self.is_dragging = False
            dx = self.drag_start_x - x
            dy = self.drag_start_y - y
            dist = math.hypot(dx, dy)
            if dist > 20:
                angle, velocity, _ = compute_shot(self.drag_start_x, self.drag_start_y, x, y, self.state.selected_weapon)

                # Determine shot count (multi-shot based on level + triple shot powerup)
                shot_count = 1
                if self.state.selected_weapon != "STANDARD":
                    if 10 <= self.state.level <= 19:
                        shot_count = 2
                    elif 20 <= self.state.level <= 29:
                        shot_count = 3
                    elif self.state.level >= 30:
                        shot_count = 4

                if self.state.triple_shot_timer > 0:
                    shot_count = max(shot_count, 3)

                # Consume ammo
                w_profile = WEAPONS[self.state.selected_weapon]
                if self.state.selected_weapon != "STANDARD" and w_profile["qty"] > 0:
                    w_profile["qty"] -= 1
                elif self.state.selected_weapon == "STANDARD":
                    self.state.lives -= 1

                # Spawn arrows
                if shot_count > 1:
                    offsets = [((i / (shot_count - 1)) - 0.5) * 0.5 for i in range(shot_count)]
                else:
                    offsets = [0.0]

                for offset in offsets:
                    self.physics.arrows.append(Arrow(
                        SETTINGS.slingshot_x, SETTINGS.slingshot_y,
                        angle + offset, velocity, self.state.selected_weapon
                    ))

                if self.state.selected_weapon != "STANDARD" and w_profile["qty"] <= 0:
                    self.state.selected_weapon = "STANDARD"

                self.audio.play("shoot")
                self.vibration.medium()

    def _update(self, dt: float) -> None:
        gs = self.state.game_state

        # 3D camera parallax tilt based on input position
        if SETTINGS.enable_parallax:
            target_tilt_x = (self.mx - SETTINGS.width / 2) / (SETTINGS.width / 2) * 24.0
            target_tilt_y = (self.my - SETTINGS.height / 2) / (SETTINGS.height / 2) * 12.0
            self._tilt_x = lerp(self._tilt_x, target_tilt_x, 0.08)
            self._tilt_y = lerp(self._tilt_y, target_tilt_y, 0.08)

        # Combo timer decay
        if gs not in (STATE_SHOP, STATE_PAUSE, STATE_GAMEOVER, STATE_VICTORY, STATE_MENU):
            self.state.global_time += dt
            if self.state.combo_multiplier > 1:
                self.state.combo_meter -= dt
                if self.state.combo_meter <= 0:
                    self.state.combo_multiplier = 1
            if self.state.triple_shot_timer > 0:
                self.state.triple_shot_timer -= dt
            if self.state.level_up_banner_time > 0:
                self.state.level_up_banner_time -= dt
            if self.state.shake_timer > 0:
                self.state.shake_timer -= dt

        # Menu updates
        if gs == STATE_MENU:
            self.name_input.update(dt, self.mx, self.my, self.touch_down)
            self.player_name = self.name_input.get_value()
            for btn in self.menu_buttons:
                btn.update(self.mx, self.my, self.touch_down, self.touch_up)
            for btn in self.difficulty_buttons:
                btn.update(self.mx, self.my, self.touch_down, self.touch_up)
            return

        # Shop / pause / gameover updates
        if gs in (STATE_SHOP, STATE_PAUSE, STATE_GAMEOVER):
            for btn in self.shop_buttons:
                btn.update(self.mx, self.my, self.touch_down, self.touch_up)
            # Update button text dynamically for costs
            self.shop_buttons[0].text = f"BUY 10 ARROWS [{30 + (self.state.level - 1) * 10} COINS]"
            self.shop_buttons[1].text = f"UPGRADE MAX HP [{50 + (self.state.level - 1) * 15} COINS]"
            return

        if gs == STATE_VICTORY:
            if self.victory_button:
                self.victory_button.update(self.mx, self.my, self.touch_down, self.touch_up)
            return

        if gs != STATE_READY:
            return

        # Ready state gameplay
        # HUD interactions
        hud_actions = self.hud.update(self.mx, self.my, self.touch_down, self.touch_up, self.state)
        for action in hud_actions:
            if action == "shop":
                self.state.game_state = STATE_SHOP
                self.audio.play("alpha")
            elif action == "pause":
                self.state.game_state = STATE_PAUSE
                self.audio.play("alpha")
            elif isinstance(action, tuple) and action[0] == "weapon":
                w_id = action[1]
                if self.state.boss_active or w_id == "STANDARD":
                    if WEAPONS[w_id]["qty"] == -1 or WEAPONS[w_id]["qty"] > 0:
                        self.state.selected_weapon = w_id
                        self.audio.play("alpha")

        # Physics updates
        prev_level = self.state.level
        self.physics.update_birds(dt, self.state)
        self.physics.update_boss(dt, self.state.global_time, self.state)
        self.physics.update_arrows(dt)

        slingshot_hitbox = pygame.Rect(SETTINGS.slingshot_x - 70, SETTINGS.slingshot_y, 140, 120)
        self.physics.update_boss_projectiles(dt, slingshot_hitbox, self.state)
        self.physics.update_powerups(dt, self.state)
        self.physics.update_particles(dt)
        self.physics.check_collisions(self.state)
        self.physics.check_level_up(self.state)

        # Sync boss state to HUD
        self.state.sync_boss(self.physics.boss)

        # Save on level up (preserve progress)
        if self.state.level != prev_level and self.state.level < 100:
            self._save()

        # Check game over
        if self.physics.is_ammo_depleted(self.state) or self.state.current_hp <= 0:
            self.state.game_state = STATE_GAMEOVER
            self.audio.play("gameover")
            self.audio.pause_music()
            self.vibration.heavy()
            self.ads.show_interstitial()
            self._save()

        # Check victory
        if self.state.level >= 100:
            self.state.game_state = STATE_VICTORY
            self.audio.play("alpha")
            self._save()

    def _draw(self) -> None:
        if self.headless or self.game_surface is None:
            return

        self.game_surface.fill(PURE_BLACK)
        self._draw_background(self.state.level)

        gs = self.state.game_state
        if gs == STATE_MENU:
            self._draw_menu()
        elif gs in (STATE_SHOP, STATE_PAUSE, STATE_GAMEOVER):
            self._draw_shop_overlay()
        elif gs == STATE_VICTORY:
            self._draw_victory()
        elif gs == STATE_READY:
            self._draw_gameplay()

        # Apply screen shake
        offset_x, offset_y = screen_shake_offset(self.state.shake_timer, self.state.shake_intensity)
        self.screen.blit(self.game_surface, (offset_x, offset_y))
        pygame.display.flip()

    def _draw_background(self, level: int) -> None:
        if 1 <= level <= 30:
            if self.sky_surface is not None:
                self.game_surface.blit(self.sky_surface, (0, 0))
            for cloud in self.clouds:
                cloud["x"] += cloud["speed"] * (1 / 60.0)
                if cloud["x"] > SETTINGS.width + 100:
                    cloud["x"] = -150
                    cloud["y"] = random.randint(20, max(40, SETTINGS.height // 3))
                pygame.draw.circle(self.game_surface, CLOUD_SHADOW, (int(cloud["x"]), int(cloud["y"])), cloud["size"])
                pygame.draw.circle(self.game_surface, CLOUD_WHITE, (int(cloud["x"]), int(cloud["y"] - 3)), cloud["size"])

        elif 31 <= level <= 60:
            self.game_surface.fill(PURE_BLACK)
            self._draw_parallax_stars(brightness=(255, 255, 255))

        elif 61 <= level <= 90:
            self.game_surface.fill(SPACE_DARK)
            if self._nebula_surface is not None:
                for i in range(3):
                    pulse = int(140 + math.sin(self.state.global_time + i) * 20)
                    self._nebula_surface.fill((0, 0, 0, 0))
                    pygame.draw.circle(self._nebula_surface, (*SPACE_NEBULA, 25), (170, 170), pulse)
                    self.game_surface.blit(self._nebula_surface,
                                           (SETTINGS.width // 4 * (i + 1) - 170, SETTINGS.height // 2 - 170),
                                           (170 - pulse, 170 - pulse, pulse * 2, pulse * 2))
            self._draw_parallax_stars(brightness=(200, 200, 255))

        elif 91 <= level <= 100:
            self.game_surface.fill(RED_BLACK)
            self._draw_parallax_stars(brightness=(255, 40, 40))

    def _draw_parallax_stars(self, brightness: Tuple[int, int, int]) -> None:
        """Draw 3D parallax star layers with subtle camera tilt."""
        if not SETTINGS.enable_parallax:
            return
        for layer in self.parallax_layers:
            for star in layer:
                star["brightness"] += math.sin(self.state.global_time * star["twinkle_speed"]) * 5
                glow = int(clamp(star["brightness"], 10, 255))
                px = int(star["x"] + self._tilt_x * star["depth"])
                py = int(star["y"] + self._tilt_y * star["depth"])
                if 0 <= px < SETTINGS.width and 0 <= py < SETTINGS.height:
                    color = (glow * brightness[0] // 255,
                             glow * brightness[1] // 255,
                             glow * brightness[2] // 255)
                    pygame.draw.circle(self.game_surface, color, (px, py), star["size"])

    def _draw_menu(self) -> None:
        cx = SETTINGS.width // 2
        title_y = 55
        subtitle_y = 120
        start_y = 235

        # Clean premium title at the very top
        draw_text(self.game_surface, "SLINGSHOT EMPIRE", cx, title_y, 52, GOLD, center=True)
        draw_text(self.game_surface, "RAPID FIRE ASSAULT", cx, subtitle_y, 24, WHITE, center=True)

        # Name input directly below subtitle
        self.name_input.draw(self.game_surface)

        # Difficulty label
        diff_lbl = get_font(20, bold=True).render("DIFFICULTY", True, WHITE)
        self.game_surface.blit(diff_lbl, (cx - diff_lbl.get_width() // 2, start_y + 35))

        for btn in self.difficulty_buttons:
            # Highlight selected difficulty
            if btn.text == self.state.difficulty:
                btn.base_color = BRIGHT_GREEN if btn.text == "EASY" else (ORANGE if btn.text == "MEDIUM" else DEEP_RED)
            btn.draw(self.game_surface)

        for btn in self.menu_buttons:
            btn.draw(self.game_surface)

    def _draw_shop_overlay(self) -> None:
        veil = pygame.Surface((SETTINGS.width, SETTINGS.height), pygame.SRCALPHA)
        veil.fill((0, 0, 0, 195))
        self.game_surface.blit(veil, (0, 0))

        cx = SETTINGS.width // 2
        cy = SETTINGS.height // 2
        pygame.draw.rect(self.game_surface, CHARCOAL, (cx - 250, cy - 200, 500, 430), border_radius=12)
        pygame.draw.rect(self.game_surface, GOLD, (cx - 250, cy - 200, 500, 430), width=3, border_radius=12)

        draw_text(self.game_surface, "EMPIRE ARSENAL SHOP", cx, cy - 165, 36, GOLD, center=True)
        draw_text(self.game_surface, f"CURRENT COINS: {self.state.coins}", cx, cy - 125, 26, WHITE, center=True)

        is_dead = self.state.game_state == STATE_GAMEOVER
        blink = int(abs(math.sin(pygame.time.get_ticks() / 250)) * 135) + 120
        ammo_color = (0, blink, 0) if (is_dead and self.state.lives <= 0) else BRIGHT_GREEN
        hp_color = (blink, 0, blink) if (is_dead and self.state.current_hp <= 0) else PURPLE

        self.shop_buttons[0].base_color = ammo_color
        self.shop_buttons[1].base_color = hp_color

        for btn in self.shop_buttons:
            btn.draw(self.game_surface)

        if self.state.game_state != STATE_GAMEOVER:
            self.continue_button.update(self.mx, self.my, self.touch_down, self.touch_up)
            self.continue_button.draw(self.game_surface)

    def _draw_victory(self) -> None:
        veil = pygame.Surface((SETTINGS.width, SETTINGS.height), pygame.SRCALPHA)
        veil.fill((10, 25, 45, 230))
        self.game_surface.blit(veil, (0, 0))

        cx = SETTINGS.width // 2
        cy = SETTINGS.height // 3
        draw_text(self.game_surface, "EMPIRE VICTORIOUS!", cx, cy - 50, 64, GOLD, center=True)
        draw_text(self.game_surface, f"CONGRATULATIONS {self.player_name}! YOU CONQUERED LEVEL 100", cx, cy + 40, 30, WHITE, center=True)
        draw_text(self.game_surface, f"ULTIMATE SCORE: {self.state.score}", cx, cy + 100, 30, NEON_CYAN, center=True)
        if self.victory_button:
            self.victory_button.update(self.mx, self.my, self.touch_down, self.touch_up)
            self.victory_button.draw(self.game_surface)

    def _draw_gameplay(self) -> None:
        # Boss or birds
        if self.state.boss_active:
            self.physics.boss.draw(self.game_surface, self.state.global_time, self.sprite_atlas)
            for proj in self.physics.boss_projectiles:
                proj.draw(self.game_surface)
        else:
            for bird in self.physics.birds:
                bird.draw(self.game_surface, self.state.global_time, self.sprite_atlas)

        # Arrows and particles
        for arrow in self.physics.arrows:
            arrow.draw(self.game_surface, self.sprite_atlas)
        self.physics.particles.draw(self.game_surface)

        # Powerups
        powerup_sprite = self.sprite_atlas.get("powerup")
        for pup in self.physics.powerups:
            if powerup_sprite is not None:
                rect = powerup_sprite.get_rect(center=(int(pup["x"]), int(pup["y"])))
                draw_drop_shadow(self.game_surface, int(pup["x"]), int(pup["y"]), 32, 32, alpha=60, blur=3)
                self.game_surface.blit(powerup_sprite, rect)
            else:
                pygame.draw.circle(self.game_surface, PURPLE, (int(pup["x"]), int(pup["y"])), 14)
                pygame.draw.circle(self.game_surface, WHITE, (int(pup["x"]), int(pup["y"])), 8)

        # Slingshot
        can_shoot = (self.state.lives > 0 or WEAPONS["PLASMA"]["qty"] > 0 or
                     WEAPONS["BALLISTA"]["qty"] > 0) and self.state.current_hp > 0
        if can_shoot and not self.is_dragging:
            draw_arrow(self.game_surface, SETTINGS.slingshot_x, SETTINGS.slingshot_y,
                       0, 0, self.state.selected_weapon, is_ready=True, atlas=self.sprite_atlas)

        draw_slingshot_base(self.game_surface, WEAPONS[self.state.selected_weapon]["color"], self.sprite_atlas)

        # Drag line
        if self.is_dragging:
            pygame.draw.line(self.game_surface, ORANGE, (SETTINGS.slingshot_x - 35, SETTINGS.slingshot_y + 25),
                             (self.mx, self.my), 4)
            pygame.draw.line(self.game_surface, ORANGE, (SETTINGS.slingshot_x + 35, SETTINGS.slingshot_y + 25),
                             (self.mx, self.my), 4)
            draw_arrow(self.game_surface, self.mx, self.my,
                       self.drag_start_x - self.mx, self.drag_start_y - self.my,
                       self.state.selected_weapon, is_ready=False, atlas=self.sprite_atlas)

        self.hud.draw(self.game_surface, self.state)

    def run(self) -> None:
        while self.running:
            dt = self.clock.tick(SETTINGS.fps) / 1000.0
            dt = min(dt, SETTINGS.dt_cap)
            self._handle_events()
            self._update(dt)
            self._draw()

        pygame.key.stop_text_input()
        pygame.quit()
        sys.exit()
