"""Entry point for Slingshot Empire.

Supports desktop run and Android (python-for-android) bootstrap.
"""

from __future__ import annotations

import sys
import os

# Ensure src/ is on the path when running from different directories.
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from core.engine import Game


def main() -> None:
    """Launch the game."""
    import argparse
    parser = argparse.ArgumentParser(description="Slingshot Empire: Invasion Overdrive Pro")
    parser.add_argument("--windowed", action="store_true", help="Run in windowed mode")
    parser.add_argument("--width", type=int, default=None, help="Window width")
    parser.add_argument("--height", type=int, default=None, help="Window height")
    parser.add_argument("--headless", action="store_true", help="Run without display (for CI/tests)")
    args, _unknown = parser.parse_known_args()

    game = Game(
        width=args.width,
        height=args.height,
        fullscreen=not args.windowed,
        headless=args.headless,
    )
    game.run()


if __name__ == "__main__":
    main()
