"""Global configuration, constants, and color/theme data.

Uses relative screen coordinates so the game adapts to any desktop or mobile
resolution in landscape mode.
"""

import math
import random
from dataclasses import dataclass, field
from typing import Tuple

__version__ = "1.0.0"

# ---------------------------------------------------------------------------
# Target design resolution (used as reference for relative layout calculations)
# ---------------------------------------------------------------------------
DESIGN_WIDTH = 1920
DESIGN_HEIGHT = 1080

# ---------------------------------------------------------------------------
# Color palette
# ---------------------------------------------------------------------------
MIDNIGHT_DARK = (15, 15, 25)
NEON_CYAN = (0, 255, 255)
DEEP_RED = (205, 92, 92)
CHARCOAL = (40, 40, 40)
BRIGHT_GREEN = (46, 139, 87)
BUTTON_HOVER = (60, 179, 113)
ORANGE = (255, 140, 0)
WHITE = (255, 255, 255)
GOLD = (255, 215, 0)
PURPLE = (148, 0, 211)
GRAY = (120, 120, 120)
DARK_GRAY = (80, 80, 80)
BLACK = (0, 0, 0)

SKY_TOP = (100, 180, 240)
SKY_BOTTOM = (210, 240, 255)
CLOUD_SHADOW = (190, 210, 230)
CLOUD_WHITE = (250, 250, 255)
PURE_BLACK = (0, 0, 0)
RED_BLACK = (30, 3, 3)
SPACE_DARK = (10, 5, 20)
SPACE_NEBULA = (90, 0, 140)

COIN_VISIBILITY_COLOR = (255, 180, 0)
NEON_YELLOW = (255, 255, 0)

BIRD_CYAN = (64, 185, 191)
BIRD_LIGHT_CYAN = (120, 215, 219)
BIRD_NAVY_TAIL = (24, 82, 92)
ALPHA_BLUE = (30, 144, 255)
ALPHA_GLOW = (0, 255, 255)

DIFFICULTY_SETTINGS = {
    "EASY":   {"boss_hp_mod": 1.0, "dmg_mod": 10, "speed_mod": 1.0},
    "MEDIUM": {"boss_hp_mod": 1.5, "dmg_mod": 15, "speed_mod": 1.2},
    "HARD":   {"boss_hp_mod": 2.2, "dmg_mod": 25, "speed_mod": 1.5},
}

# ---------------------------------------------------------------------------
# Runtime settings (mutable, adapts to screen)
# ---------------------------------------------------------------------------
@dataclass
class GameSettings:
    """Container for runtime game settings and screen metrics."""

    width: int = DESIGN_WIDTH
    height: int = DESIGN_HEIGHT
    fps: int = 60
    dt_cap: float = 0.1
    save_path: str = "player_data.json"

    # Safe area margins for mobile notches / navigation bars
    safe_left: int = 0
    safe_right: int = 0
    safe_top: int = 0
    safe_bottom: int = 0

    # Layout helpers (updated on resize)
    slingshot_x: float = DESIGN_WIDTH / 2
    slingshot_y: float = DESIGN_HEIGHT - 180
    hud_margin: int = 24

    # 3D / parallax toggles
    enable_parallax: bool = True
    enable_shadows: bool = True
    enable_perspective: bool = True
    enable_vibration: bool = True
    enable_ads: bool = False

    def scale_x(self, x: float) -> float:
        return x * self.width / DESIGN_WIDTH

    def scale_y(self, y: float) -> float:
        return y * self.height / DESIGN_HEIGHT

    def scale(self, v: float) -> float:
        return v * min(self.width / DESIGN_WIDTH, self.height / DESIGN_HEIGHT)

    def clamp_to_screen(self, rect, padding: int = 0) -> Tuple[float, float]:
        x = max(self.safe_left + padding, min(self.width - self.safe_right - padding - rect.width, rect.x))
        y = max(self.safe_top + padding, min(self.height - self.safe_bottom - padding - rect.height, rect.y))
        return x, y


SETTINGS = GameSettings()


def update_settings_for_screen(width: int, height: int) -> None:
    """Recalculate layout metrics after a screen resize or orientation change."""
    SETTINGS.width = width
    SETTINGS.height = height
    # Keep slingshot centered horizontally and near the bottom within safe area
    SETTINGS.slingshot_x = width / 2
    SETTINGS.slingshot_y = max(height * 0.72, height - 220)

    # Mobile safe area estimation (can be overridden by OS events on Android)
    if height > width:
        # Portrait is not supported for this landscape game, but keep valid layout
        SETTINGS.slingshot_y = height * 0.78


# ---------------------------------------------------------------------------
# Game balance data
# ---------------------------------------------------------------------------
MAX_BIRDS_ON_SCREEN = 4
MAX_COMBO_TIME = 1.5
MAX_COMBO_MULTIPLIER = 3
CONTINUE_COST = 50

BOSS_TYPES_POOL = ["PHOENIX", "DRONE", "UFO", "MOTHERSHIP", "OMEGA"]

WEAPONS = {
    "STANDARD": {
        "name": "Wooden Sling",
        "color": CHARCOAL,
        "damage": 1,
        "vel_mod": 1.0,
        "qty": -1,  # infinite
    },
    "PLASMA": {
        "name": "Plasma Arc",
        "color": NEON_CYAN,
        "damage": 2,
        "vel_mod": 2.0,
        "qty": 5,
    },
    "BALLISTA": {
        "name": "Crimson Doom",
        "color": DEEP_RED,
        "damage": 5,
        "vel_mod": 0.9,
        "qty": 5,
    },
}


def reset_weapons() -> None:
    WEAPONS["STANDARD"]["qty"] = -1
    WEAPONS["PLASMA"]["qty"] = 5
    WEAPONS["BALLISTA"]["qty"] = 5


def calculate_invasion_target(level: int) -> int:
    return 40 + (level - 1) * 5


def calculate_boss_waves(level: int) -> int:
    if 1 <= level <= 30:
        return 1
    elif 31 <= level <= 60:
        return 2
    elif 61 <= level <= 100:
        return 3
    return 1


@dataclass
class Objective:
    desc: str = "Destroy 5 birds to unlock bonus"
    target: int = 5
    current: int = 0
    reward_ammo: int = 5

    def reset(self) -> None:
        self.current = 0
        self.target = random.choice([5, 8, 10])
        self.desc = f"Destroy {self.target} birds for Mixed Special Ammo Package!"


@dataclass
class PlayerProfile:
    name: str = "Player 1"
    score: int = 0
    coins: int = 0
    current_level: int = 1
    lives: int = 15
    max_hp: int = 100
    current_hp: int = 100
    plasma_qty: int = 5
    ballista_qty: int = 5
    difficulty: str = "MEDIUM"


# Game state string constants
STATE_MENU = "MENU"
STATE_READY = "READY"
STATE_SHOP = "SHOP"
STATE_PAUSE = "PAUSE"
STATE_GAMEOVER = "GAMEOVER"
STATE_VICTORY = "VICTORY"


@dataclass
class GameStateData:
    score: int = 0
    coins: int = 0
    level: int = 1
    lives: int = 15
    max_hp: int = 100
    current_hp: int = 100
    combo_multiplier: int = 1
    combo_meter: float = 0.0
    triple_shot_timer: float = 0.0
    level_up_banner_time: float = 0.0
    difficulty: str = "MEDIUM"
    objective: Objective = field(default_factory=Objective)
    selected_weapon: str = "STANDARD"
    global_time: float = 0.0

    game_state: str = STATE_MENU
    level_score_tracker: int = 0
    points_for_level_up: int = 40
    shake_timer: float = 0.0
    shake_intensity: int = 0

    # Boss state mirror (synced from physics.boss)
    boss_active: bool = False
    boss_current_wave: int = 1
    boss_total_waves: int = 1
    boss_current_hp: int = 5
    boss_max_hp: int = 5

    def update_level_target(self) -> None:
        self.points_for_level_up = calculate_invasion_target(self.level)

    def sync_boss(self, boss) -> None:
        self.boss_active = boss.active
        self.boss_current_wave = boss.wave_index
        self.boss_total_waves = boss.total_waves
        self.boss_current_hp = boss.current_hp
        self.boss_max_hp = boss.max_hp
